
public class StringDemo {
	public static void main(String args[])
	{
	String s="hello";
	s.toUpperCase();
	System.out.println(s);
	System.out.println(s.toUpperCase());
	}
}
