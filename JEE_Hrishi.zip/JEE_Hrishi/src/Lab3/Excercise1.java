package Lab3;

public class Excercise1 {					//return the second smallest element from array
	int getSecondSmallest(int a[])
	{
		for(int i=0;i<a.length;i++)
		{
			for(int j=i;j<a.length-1;j++)
			{
				if(a[i]>a[j+1])
				{
					int temp;
					temp=a[i];
					a[i]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
		return a[1];
	}
	public static void main(String args[])
	{
		Excercise1 e=new Excercise1();
		int a[]={10,5,7,12,6};
		int result=e.getSecondSmallest(a);
		System.out.println(result);
	}
	
	

}
