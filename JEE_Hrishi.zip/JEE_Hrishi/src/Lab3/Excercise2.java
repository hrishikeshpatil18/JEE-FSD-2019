package Lab3;				//String to uppercase and lowercase

import java.util.Arrays;
import java.util.Scanner;

public class Excercise2 {
	
	static String[] getSorted(String str[])
	{
		String s="";
		for(int i=0;i<str.length;i++)
		{
			for(int j=i+1;j<str.length;j++)
			{
				if(str[i].compareTo(str[j])>0)
				{
					s=str[i];
					str[i]=str[j];
					str[j]=s;
				}
			}
		}
		
		int len=(str.length%2);
		if(len==0)  						//if length of string array is even
		{
			for(int i=0;i<str.length/2;i++)
			{
				String sp=str[i];
				str[i]=sp.toUpperCase();
			}
		}
		else								//if length of string array is odd
		{
			for(int i=0;i<(str.length/2)+1;i++)
			{
				String sp=str[i];
				str[i]=sp.toUpperCase();
			}
		}
		return str;
		
	}
	
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of string array: ");
		int size=sc.nextInt();
		String str[]=new String[size];
		
		for(int i=0;i<size;i++)
		{
			str[i]=sc.next();
			
		}
		
		String ans[]=getSorted(str);
		for(int i=0;i<ans.length;i++)
		{
			System.out.println(ans[i]);
		}
		
	}

}
