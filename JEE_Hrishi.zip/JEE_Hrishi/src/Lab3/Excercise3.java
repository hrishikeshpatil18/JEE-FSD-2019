package Lab3;						//Reverse and sort the array

import java.util.Arrays;

public class Excercise3 {
	static int[] getSorted(int arr[])
	{ 
		 String a="";
		 String c="";
		int n=arr.length;
		for(int i=0;i<arr.length;i++)
		{
			a=a+Integer.toString(arr[i]);
		}
		StringBuilder sb = new StringBuilder(a);
		 sb = sb.reverse();
		 c = new String(sb);
		// System.out.print(sb);
		 
		 char b[]=c.toCharArray();
			Arrays.sort(b);
			for(int i=0;i<b.length;i++)
			{
				arr[i]=Character.getNumericValue(b[i]);
			}
		
		return arr;
	}
	
	
	public static void main(String args[])
	{
		int array[]={1,5,3,8,4,6,2};
		int result[]=getSorted(array);
		for(int i=0;i<result.length;i++)
		{
			System.out.println(result[i]);
		}
	}
}
