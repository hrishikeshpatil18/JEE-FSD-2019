package Lab3;				//return the number of count of each character

import java.util.Arrays;
import java.util.Scanner;

public class Excercise4 {

		static void countChar(char arr[])
		{
			int count=0;
			char temp[]=arr;
			for(int  i=0;i<arr.length;i++)
			{
				for(int j=i+1;j<arr.length;j++)
				{
					
					if(temp[i]==arr[j])
						count++;
				}
				System.out.println("Number of occurences of "+temp[i]+" is "+count);
			}
			
		}
		
		public static void main(String args[])
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the size of array");
			int size=sc.nextInt();
			
			char array[]=new char[size];
			for(int i=0;i<size;i++)
			{
				array[i]=sc.next().charAt(0);
			}
			
		
			countChar(array);
			
			
		}

	}


