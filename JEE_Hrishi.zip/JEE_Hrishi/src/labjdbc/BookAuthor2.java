package labjdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class BookAuthor2 
{
	static int count=1;	
	public static void main(String agrs[])
	{
			int authorId,bookId,price;
			String authorName,title;
			String s;
			long phNo;
			
			Scanner scanner = new Scanner(System.in);
			
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg517","training517");
					PreparedStatement stmt;
					Statement stm;
					ResultSet rs;
					
					do
					{
						System.out.println("1. Create Table");
						System.out.println("2. Insert into Table");
						System.out.println("3. Update Table");
						System.out.println("4. Delete Table Records");
						System.out.println("5. select from Table");
						System.out.println("Enter your choice");
						int ch=scanner.nextInt();
						switch(ch)
						{
						case 1:
							break;
								
						case 2:
							System.out.println("Enter the id of book");
							bookId = scanner.nextInt();
							System.out.println("Enter the title of book");
							title = scanner.next();
							System.out.println("Enter the price of book");
							price = scanner.nextInt();
							System.out.println("Enter the id of author");
							authorId = scanner.nextInt();
							System.out.println("Enter the name of author");
							authorName = scanner.next();
								
							stmt=con.prepareStatement("insert into booknew values(?,?,?,?,?,?)");
							stmt.setInt(1,count);
							count++;
							stmt.setInt(2,bookId);
							stmt.setString(3,title);
							stmt.setInt(4,price);
							stmt.setInt(5,authorId);
							stmt.setString(6,authorName);
								
							stmt.executeUpdate();
							System.out.println("One row inserted");
							break;
								
						}
						System.out.println("Do you want to continue ? Y/N");
						s=scanner.next();
					}while(s.equals("Y") || s.equals("y"));
				}
						catch(SQLException e) {System.out.println(e);}
						catch(ClassNotFoundException e) {System.out.println(e);}
	}

}
