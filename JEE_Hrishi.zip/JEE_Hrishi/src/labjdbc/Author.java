package labjdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import java.util.Scanner;

public class Author 
{
	Scanner scanner = new Scanner(System.in);
	int ch;
	
	
	public static void main(String args[])
	{
		int authorId;
		String fName,mName,lName;
		String s;
		long phNo;
		Scanner scanner = new Scanner(System.in);
		
			try
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg517","training517");
				PreparedStatement stmt;
				Statement stm;
				ResultSet rs;
			do
			{
				System.out.println("1. Create Table");
				System.out.println("2. Insert into Table");
				System.out.println("3. Update Table");
				System.out.println("4. Delete Table Records");
				System.out.println("5. select from Table");
				System.out.println("Enter your choice");
				int ch=scanner.nextInt();
				switch(ch)
				{
					case 1:
						
						
						break;
						
					case 2:
						System.out.println("Enter the id of author");
						authorId = scanner.nextInt();
						System.out.println("Enter the first name of author");
						fName = scanner.next();
						System.out.println("Enter the middle name of author");
						mName = scanner.next();
						System.out.println("Enter the last name of author");
						lName = scanner.next();
						System.out.println("Enter the phone no of author");
						phNo = scanner.nextLong();
						
						stmt=con.prepareStatement("insert into Author values(?,?,?,?,?)");
						
						stmt.setInt(1,authorId);
						stmt.setString(2,fName);
						stmt.setString(3,mName);
						stmt.setString(4,lName);
						stmt.setLong(5,phNo);
						
						stmt.executeUpdate();
						System.out.println("One row inserted");
						break;
						
					case 3:
						/*System.out.println("Update Author set");
						String authorField1=scanner.next();*/
						System.out.println("firstname ");
						String authorValue1=scanner.next();
						/*System.out.println("where ");
						String authorField2=scanner.next();*/
						System.out.println("id= ");
						int authorValue2=scanner.nextInt();
						stmt=con.prepareStatement("update Author set firstname= ? where author_id= ?");
						stmt.setString(1,authorValue1);
						stmt.setInt(2,authorValue2);
						
						//stmt.setString(3,authorField2);
						//stmt.setInt(4,authorValue2);
						
						stmt.executeUpdate();
						System.out.println("One row updated");
						break;
						
					case 4:
						System.out.println("Enter the id of author");
						int authorId1 = scanner.nextInt();
						stmt=con.prepareStatement("DELETE FROM Author WHERE AUTHOR_ID= ?");
						
						stmt.setInt(1,authorId1);
						stmt.executeUpdate();
						
						System.out.println("Row Deleted");
						break;
						
					case 5:
						
						System.out.println("Enter the author id to display record");
						int id=scanner.nextInt();
						stmt=con.prepareStatement("select * from Author where author_id= ?");
						stmt.setInt(1,id);
						rs=stmt.executeQuery();
						
						/*stm=con.createStatement();
						System.out.println("Enter the author id to display record");
						int id=scanner.nextInt();
						String query="select * from author where author_id = '" + id + "'";
						rs=stm.executeQuery(query);*/
						while(rs.next())
							System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getLong(5));
						break;
				}
				System.out.println("Do you want to continue ? Y/N");
				s=scanner.next();
			}while(s.equals("Y") || s.equals("y"));
			}
			catch(SQLException e) {System.out.println(e);}
			catch(ClassNotFoundException e) {System.out.println(e);}
			
		}
	
	/*void insertIntoTable()
	{
		
		System.out.println("Enter the id of author");
		int authorId = scanner.nextInt();
		System.out.println("Enter the first name of author");
		String fName = scanner.next();
		System.out.println("Enter the middle name of author");
		String mName = scanner.next();
		System.out.println("Enter the last name of author");
		String lName = scanner.next();
		System.out.println("Enter the phone no of author");
		long phNo = scanner.nextLong();
		
		PreparedStatement stmt=con.prepareStatement("update employee1 set emp_name=? where emp_id=?");
	}*/
}

/*class Main
{
	int authorId;
	String fName,mName,lName;
	long phNo;
	 Scanner scanner = new Scanner(System.in);
	 void insertIntoTable()
	{
		
		System.out.println("Enter the id of author");
		authorId=scanner.nextInt();
		System.out.println("Enter the first name of author");
		fName=scanner.next();
		System.out.println("Enter the middle name of author");
		mName=scanner.next();
		System.out.println("Enter the last name of author");
		lName=scanner.next();
		System.out.println("Enter the phone no of author");
		phNo=scanner.nextLong();
	}
}*/
