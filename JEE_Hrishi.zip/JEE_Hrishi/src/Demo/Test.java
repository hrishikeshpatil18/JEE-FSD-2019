package Demo;

public class Test {
	public static void main(String args[])
	{
		Student s[]=new Student[2];
		s[0]=new Student("abc",10);
		s[1]=new Student("xyz",11);
		s[0].show();
		s[1].show();
	}

}
