package Demo;
//import java.util.Scanner;
public class Employee 
{
	public static void main(String args[])
	{
		//Scanner sc=new Scanner(System.in);
		//int a=sc.nextInt();
		//System.out.println(a);
		
		int a[][]={{1,2},{2,3},{3,4}};
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			System.out.print(a[i][j]);
			System.out.println("");
		}
	}

}
