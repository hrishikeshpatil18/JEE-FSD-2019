package Demo;

public class Student {
	String name;
	int roll;
	Student(String name,int roll)
	{
		this.name=name;
		this.roll=roll;
	}
	void show()
	{
		System.out.println(name);
		System.out.println(roll);
	}
}
