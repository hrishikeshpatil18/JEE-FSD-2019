
public class Employee {
	String name;
	int id;
	Employee(String name,int id)
	{
		this.name=name;
		this.id=id;
	}
	public boolean equals(Employee e)
	{
		boolean b=false;
		if(this.id==e.id && this.name.equals(e.name))
			b=true;
		return b;
	}
	
	public static void main(String args[])
	{
		Employee e1=new Employee("abc",1);
		Employee e2=new Employee("abc",1);
		
		boolean b=e1==e2;
		System.out.println(b);
		System.out.println(e1.equals(e2));
	}

}
