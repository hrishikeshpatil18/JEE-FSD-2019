package Lab1;						//difference between sum of squares and square of sums of n natural number

public class Excercise2 {
	
	int n;
	int calculateDifference(int num)
	{
		n=num;
		int sum1=0,sum2=0;
		int difference=0;
		for(int i=1;i<=n;i++)
		{
			int p=i*i;
			sum1=sum1+p;
			
		}
		System.out.println("Sum of Square: "+sum1);
		for(int i=1;i<=n;i++)
		{
			sum2=sum2+i;
			
			
		}
		sum2=sum2*sum2;
		System.out.println("square of sum: "+sum2);
		difference=sum1-sum2;
		return difference;
	}
	

public static void main(String args[])
{
	Excercise2 e=new Excercise2();
	int result=e.calculateDifference(4);
	System.out.println("Difference: "+result);
	boolean b=e instanceof Object;
	System.out.println(b);
	
}
}