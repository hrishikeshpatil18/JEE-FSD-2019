package Lab1;

public class Excercise3 {              //number is power of two or not
	
	boolean checkNumber(int num)
	{
		/*if(num<=0);
		{
			return false;
		}*/
		while(num>1)
		{
			if(num%2 != 0)
			
				return false;
			
			num=num/2;
		}
		return true;
	}
	
	
	public static void main(String args[])
	{
		Excercise3 e=new Excercise3();
		boolean result=e.checkNumber(16);
		System.out.println(result);
		
	}

}
