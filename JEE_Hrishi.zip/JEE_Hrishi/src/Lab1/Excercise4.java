package Lab1;					//sequence of digit of number is increasing order or not

import java.util.Scanner;

public class Excercise4 {
	static boolean checkNumber(int num)
	{
		int r1=0,r2=0;
		 r1=num%10;
		num=num/10;
		
		while(num>0)
		{
			r2=num%10;
			if(r1>r2)
			{
				num=num/10;
				r1=r2;
			}
			else
			{
			return false;
			}
		}
		return true;
	}

	public static void main(String args[])
	{
		//Excercise4 e=new Excercise4();
		//Scanner sc=new Scanner(System.in);
		//int a=sc.nextInt();
		boolean result=checkNumber(1234);
		System.out.println(result);
	}
}
