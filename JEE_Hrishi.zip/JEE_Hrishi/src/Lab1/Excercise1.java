package Lab1;					//sum of first n natural numbers divisible by 3 & 5
import java.util.Scanner;
public class Excercise1 {
	int n;
	int calculateSum(int num)
	{
		n=num;
		int result=0;
		for(int i=0;i<n;i++)
		{
			if(i%3==0 || i%5==0)
			{
				result=result+i;
			}
		}
		return result;
	}
public static void main(String agrs[])
{
	Excercise1 e1=new Excercise1();
	Scanner sc=new Scanner(System.in);
	int var=sc.nextInt();
	int r=e1.calculateSum(var);
	System.out.println(r);
}
}
