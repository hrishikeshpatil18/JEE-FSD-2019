package lab10;

public class FileProgram {
	public static void main(String args[])
	{
		CopyDataThread c=new CopyDataThread();
		c.start();
	}

}
