package dao;

import java.util.HashMap;
import java.util.Set;

import bean.Employee;

public class EmployeeDAO 
{
	
static HashMap <Integer,Employee>hash=new HashMap<Integer,Employee>();
	
	public void storeEmployeeDetails(int id,Employee employee)
	{
		hash.put(id, employee);
		System.out.println("Employee Details Registered Successfully...!!");
		System.out.println(hash);
		
	}
	
	public Employee getEmpDetails(int id)
	{
		Set <Integer> set=hash.keySet();
		for(int i:set)
		{
			if(i==id)
			{
				return hash.get(i);
			}
		}
		return null;
	}

}
