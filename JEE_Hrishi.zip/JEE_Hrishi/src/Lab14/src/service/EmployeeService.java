package service;

import bean.Employee;
import dao.EmployeeDAO;

public class EmployeeService 
{
	Employee employee=new Employee();
	 EmployeeDAO empdao=new EmployeeDAO();
	public void storeEmployee(int id, Employee emp)
	{
		empdao.storeEmployeeDetails(id,emp);
	}
	
	public String findEmpScheme(double sal, String des)
	{
		String scheme = "";
		if(sal>5000 && sal<20000 && des.equalsIgnoreCase("System Associate"))
		{
			scheme="Scheme C";
			employee.setInsurancescheme(scheme);
			return scheme;
		}
		
		if(sal>=20000 && sal<40000 && des.equalsIgnoreCase("Programmer"))
		{
			scheme="Scheme B ";
			employee.setInsurancescheme(scheme);
			return scheme;
		}
		
		if(sal>=40000 && des.equalsIgnoreCase("Manager"))
		{
			scheme="Scheme A ";
			employee.setInsurancescheme(scheme);
			return scheme;
		}
		
		if(sal<5000 && des.equalsIgnoreCase("Clerk"))
		{
			scheme="No Scheme";
			employee.setInsurancescheme(scheme);
			return scheme;
		}
		return "Not Valid";
		
	}
	
	public Employee getDetails(int id)
	{
		 return(empdao.getEmpDetails(id));
	}
}
