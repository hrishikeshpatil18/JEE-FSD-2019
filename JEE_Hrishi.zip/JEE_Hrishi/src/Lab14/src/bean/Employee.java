package bean;

public class Employee {
	int empid;
	String empName, designation, insurancescheme;
	double salary;
	
	
	public Employee()
	{
		
	}
	public Employee(int empid, String empName, String designation, double salary) {
		super();
		this.empid = empid;
		this.empName = empName;
		this.designation = designation;
		this.insurancescheme=insurancescheme;
		this.salary = salary;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsurancescheme() {
		return insurancescheme;
	}
	public void setInsurancescheme(String insurancescheme) {
		this.insurancescheme = insurancescheme;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empName=" + empName + ", designation=" + designation
				+", insurancescheme=" + insurancescheme +", salary=" + salary + "]";
	}
	
	

}
