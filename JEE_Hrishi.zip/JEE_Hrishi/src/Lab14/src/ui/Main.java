package ui;

import java.util.Scanner;

import bean.Employee;
import service.EmployeeService;

public class Main 
{
	static Scanner scanner = new Scanner(System.in);

 
	
	static void registerEmpDetails()
	{
		EmployeeService   empserv=new EmployeeService();
		System.out.println("Enter the employee Id");
		int id=scanner.nextInt();
		System.out.println("Enter the name of employee");
		String name=scanner.next();
		System.out.println("Enter the designation of employee");
		String des=scanner.next();
		System.out.println("Enter the salary of employee");
		double sal=scanner.nextDouble();
		
		Employee employee=new Employee(id,name,des,sal);
		System.out.println(employee);
		
		empserv.storeEmployee(employee.getEmpid(),employee);
	}

	static void findScheme()
	{
		EmployeeService   empserv=new EmployeeService();
		System.out.println("Enter the salary of employee");
		double sal=scanner.nextDouble();
		System.out.println("Enter the designation of employee");
		String des=scanner.next();
		String result=empserv.findEmpScheme(sal,des);
		System.out.println(result);
	}
	
	static void getDetails()
	{
		EmployeeService   empserv=new EmployeeService();
		System.out.println("Enter the employee Id");
		int id=scanner.nextInt();
		Employee employee= empserv.getDetails(id);
		System.out.println(employee);
	}
	
	
	public static void main(String args[])
	{
		int choice;
		String s;
		//Main main=new Main();
		do
		{
			System.out.println("Register employee details");
			System.out.println("Find the insurance scheme");
			System.out.println("Display details of employee");
			System.out.println("Enter your choice");
			choice=scanner.nextInt();
			switch(choice)
			{
				
			case 1:
				registerEmpDetails();
				break;
			case 2:
				findScheme();
				break;
			case 3:
				getDetails();
				break;
				
			}
			System.out.println("Do you want to continue..? Y/y");
			s=scanner.next();
		}while(s.equals("Y") || s.equals("y"));
	}

}
