package jdbcdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ResultSetDemo {
	public static void main(String agrs[])
	{
	
		try 
		{

			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg517","training517");
			Statement stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE , ResultSet.CONCUR_UPDATABLE);
			
			ResultSet results=stmt.executeQuery("select emp_id,emp_name from employee1");
			int concurrency = results.getConcurrency();
			System.out.println(concurrency);
			System.out.println(ResultSet.CONCUR_UPDATABLE);
			if(concurrency==ResultSet.CONCUR_UPDATABLE)
			{
				results.absolute(2);
				results.updateString(2,"hp");
				results.updateRow();
			}
			else
			{
				System.out.println("Resultset is not an updatable resultset");
			}
			con.close();
		}
		catch(Exception e) {System.out.println(e);}
	}
}
