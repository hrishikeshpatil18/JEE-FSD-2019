package jdbcdemo;

import java.sql.*;
import java.util.Scanner;

public class OracleDemo {
	public static void main(String agrs[])
	{
		Scanner scanner =new Scanner(System.in);
		int empId;
		String empName;
		double empSalary;
		try 
		{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg517","training517");
			/*
			 * ********with static query ***********
			 * Statement stmt=con.createStatement();
			stmt.execute("update employee1 set emp_name='Kartik' where emp_id=2");
			System.out.println("row updated");
			stmt.execute("insert into employee1 values(4, 'Mandeep',7000)");
			System.out.println("row added");
			stmt.execute("insert into employee1 values(5, 'Faizal',9000)");*/
			
			
			/*
			 *  * ********with dyanamic query ***********
			 *  System.out.println("Enter the name of employee you want to update");
			empName=scanner.nextLine();
			System.out.println("Enter the id of employee where you want to update the name");
			empId=scanner.nextInt();
			PreparedStatement stmt=con.prepareStatement("update employee1 set emp_name=? where emp_id=?");
			
			stmt.setString(1,empName);
			stmt.setInt(2,empId);
			
			stmt.executeUpdate();*/
			
			/*Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from employee1");
			System.out.println(rs);
			while(rs.next())
				System.out.println(rs.getInt("emp_id")+" "+rs.getString("emp_name")+" "+rs.getDouble(3));*/
			
			
			
			con.close();
		}
		catch(Exception e) {System.out.println(e);}
	}

}
