package Lab2;

public abstract class MediaItem extends Item {

	public MediaItem(int idNumber, String title, int copies) {
		super(idNumber, title, copies);
		// TODO Auto-generated constructor stub
	}
	

}
