package Lab2;

public class Book extends WrittenItem {

	public Book(int idNumber, String title, int copies) {
		super(idNumber, title, copies);
		// TODO Auto-generated constructor stub
	}

}
