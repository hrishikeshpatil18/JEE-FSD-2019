package Lab2;

public abstract class WrittenItem extends Item{
	private String author;
	public WrittenItem(int idNumber, String title, int copies) {
		super(idNumber, title, copies);
		// TODO Auto-generated constructor stub
	}

	
	
	

}
