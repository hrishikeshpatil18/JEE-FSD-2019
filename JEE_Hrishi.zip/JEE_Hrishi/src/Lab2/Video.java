package Lab2;

public class Video extends MediaItem{
	private String director;
	private String genre;
	private int year;

	public Video(int idNumber, String title, int copies) {
		super(idNumber, title, copies);
		// TODO Auto-generated constructor stub
	}

}
