package Lab2;

public class CD extends MediaItem{
	private String artist;
	private String genre;

	public CD(int idNumber, String title, int copies) {
		super(idNumber, title, copies);
		// TODO Auto-generated constructor stub
	}
	

}
