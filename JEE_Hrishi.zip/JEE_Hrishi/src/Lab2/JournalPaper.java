package Lab2;

public class JournalPaper extends WrittenItem {

	public JournalPaper(int idNumber, String title, int copies) {
		super(idNumber, title, copies);
		// TODO Auto-generated constructor stub
	}

}
