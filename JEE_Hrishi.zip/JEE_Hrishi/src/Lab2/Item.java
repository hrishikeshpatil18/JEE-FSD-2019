package Lab2;

public abstract class Item {
	private int idNumber;
	private String title;
	private int copies;
	
	public Item(int idNumber, String title, int copies) {
		super();
		this.idNumber = idNumber;
		this.title = title;
		this.copies = copies;
	}

	public int getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(int idNumber) {
		this.idNumber = idNumber;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getCopies() {
		return copies;
	}

	public void setCopies(int copies) {
		this.copies = copies;
	}

	@Override
	public String toString() {
		return "Item [idNumber=" + idNumber + ", title=" + title + ", copies=" + copies + "]";
	}
	
	
	

}
