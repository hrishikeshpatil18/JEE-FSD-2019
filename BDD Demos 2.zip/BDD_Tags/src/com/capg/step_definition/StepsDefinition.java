package com.capg.step_definition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefinition {

	WebDriver driver;

	@Given("^navigate to ICompass URL$")
	public void navigate_to_ICompass_URL() throws Throwable {

		driver = WebUtil.getWebDriver();
		String url = "https://icompassweb.fs.capgemini.com";
		driver.get(url);

	}

	@When("^user enters the valid username \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_enters_the_valid_username_and_valid_password(String username, String password) throws Throwable {

		WebElement userTextField = driver.findElement(By.id("userName"));
		WebElement passwordTextField = driver.findElement(By.id("password"));

		userTextField.sendKeys(username);
		passwordTextField.sendKeys(password);

	}

	@Then("^login Successful$")
	public void login_Successful() throws Throwable {

		WebElement loginButton = driver.findElement(By.id("loginButton"));
		loginButton.click();
		driver.close();

	}

	@Given("^navigate to Google URL$")
	public void navigate_to_Google_URL() throws Throwable {
		
		driver = WebUtil.getWebDriver();
		String url = "http:\\www.google.com";
		driver.navigate().to(url);							//alternate to get() method

	}

	@When("^user enters the input \"([^\"]*)\"$")
	public void user_enters_the_input(String input) throws Throwable {
		
		 WebElement searchField =  driver.findElement(By.name("q"));
		 searchField.sendKeys(input);
		 searchField.sendKeys("\n");

	}

	@Then("^climate details display$")
	public void climate_details_display() throws Throwable {
		
		System.out.println("climate details displayed");

	}

	@When("^user clicks on image link$")
	public void user_clicks_on_image_link() throws Throwable {
		
		
		 WebElement imageLink = driver.findElement(By.className("gb_e"));
		 imageLink.click();

	}

	@Then("^display the image page$")
	public void display_the_image_page() throws Throwable {
		System.out.println("images page displayed");
		
		driver.close();

	}

}
