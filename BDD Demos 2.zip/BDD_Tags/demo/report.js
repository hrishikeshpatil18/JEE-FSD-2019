$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/login.feature");
formatter.feature({
  "line": 3,
  "name": "Multiple scenario testing",
  "description": "",
  "id": "multiple-scenario-testing",
  "keyword": "Feature",
  "tags": [
    {
      "line": 2,
      "name": "@Test"
    }
  ]
});
formatter.scenario({
  "line": 7,
  "name": "Login to Icompass with valid credentials",
  "description": "",
  "id": "multiple-scenario-testing;login-to-icompass-with-valid-credentials",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "navigate to ICompass URL",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "user enters the valid username \"190065\" and valid password \"Love*Care\"",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "login Successful",
  "keyword": "Then "
});
formatter.match({
  "location": "StepsDefinition.navigate_to_ICompass_URL()"
});
formatter.result({
  "duration": 8415538600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "190065",
      "offset": 32
    },
    {
      "val": "Love*Care",
      "offset": 60
    }
  ],
  "location": "StepsDefinition.user_enters_the_valid_username_and_valid_password(String,String)"
});
formatter.result({
  "duration": 227926200,
  "status": "passed"
});
formatter.match({
  "location": "StepsDefinition.login_Successful()"
});
formatter.result({
  "duration": 380011200,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Display the climate details",
  "description": "",
  "id": "multiple-scenario-testing;display-the-climate-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "navigate to Google URL",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "user enters the input \"Chennai Climate\"",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "climate details display",
  "keyword": "Then "
});
formatter.match({
  "location": "StepsDefinition.navigate_to_Google_URL()"
});
formatter.result({
  "duration": 4759102100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Chennai Climate",
      "offset": 23
    }
  ],
  "location": "StepsDefinition.user_enters_the_input(String)"
});
formatter.result({
  "duration": 2291525000,
  "status": "passed"
});
formatter.match({
  "location": "StepsDefinition.climate_details_display()"
});
formatter.result({
  "duration": 83700,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "Display the google images",
  "description": "",
  "id": "multiple-scenario-testing;display-the-google-images",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 22,
  "name": "navigate to Google URL",
  "keyword": "Given "
});
formatter.step({
  "line": 23,
  "name": "user clicks on image link",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "display the image page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepsDefinition.navigate_to_Google_URL()"
});
formatter.result({
  "duration": 5680093400,
  "status": "passed"
});
formatter.match({
  "location": "StepsDefinition.user_clicks_on_image_link()"
});
formatter.result({
  "duration": 538474200,
  "status": "passed"
});
formatter.match({
  "location": "StepsDefinition.display_the_image_page()"
});
formatter.result({
  "duration": 329525900,
  "status": "passed"
});
});