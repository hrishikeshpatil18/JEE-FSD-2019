package com.capg.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.capg.pom.PageObjectRepository;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	
	
	
	WebDriver driver;
	PageObjectRepository pageFactory;
	
	
	@Given("^Open browser and enter the spicejet URL$")
	public void open_browser_and_enter_the_spicejet_URL() throws Throwable {
		
		
		driver = PageObjectRepository.getWebDriver();
		
		String url = "https://www.spicejet.com/";
	
		driver.get(url);
		pageFactory = new PageObjectRepository(driver);
	   
	}

	@When("^user enters the departure and arrival city$")
	public void user_enters_the_departure_and_arrival_city() throws Throwable {
	   
		//WebElement departureCity = pageFactory.getDepartureCity();
		
		
		//WebElement arrivalCity = pageFactory.getArrivalCity();
		
		/*Select continents =new Select(driver.findElement(By.xpath("//*[@id=\"ctl00_mainContent_ddl_originStation1\"]")));
        continents.selectByValue("BOM");*/
		
		
	}

	@Then("^Successfully selected the cities$")
	public void successfully_selected_the_cities() throws Throwable {
	   
	}

	@Given("^user is on spicejet home page$")
	public void user_is_on_spicejet_home_page() throws Throwable {
	  
	}

	@When("^user enters the departure and return date$")
	public void user_enters_the_departure_and_return_date() throws Throwable {
	   
	}

	@Then("^successfully selected the dates$")
	public void successfully_selected_the_dates() throws Throwable {
	   
		WebElement departDate = pageFactory.getDepartDate();
		WebElement returntDate = pageFactory.getReturnDate();
		departDate.click();
		
	}

	@When("^user enters the passenger count$")
	public void user_enters_the_passenger_count() throws Throwable {
	  
	}

	@Then("^successfully entered the passenger count$")
	public void successfully_entered_the_passenger_count() throws Throwable {
	    
	}

	@When("^user enters the type of currency$")
	public void user_enters_the_type_of_currency() throws Throwable {
	 
	}

	@Then("^successfully selected the currency$")
	public void successfully_selected_the_currency() throws Throwable {
	   
	}

	@When("^user clicks the search button$")
	public void user_clicks_the_search_button() throws Throwable {
	   
	}

	@Then("^successfully displayed the booking info$")
	public void successfully_displayed_the_booking_info() throws Throwable {
	    
	}


}
