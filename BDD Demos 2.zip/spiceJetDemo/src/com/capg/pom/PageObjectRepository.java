package com.capg.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageObjectRepository {

	static WebDriver driver;
	
	@FindBy(id="ctl00_mainContent_ddl_originStation1")
	@CacheLookup
	WebElement departureCity;
	
	@FindBy(id="ctl00_mainContent_ddl_destinationStation1")
	@CacheLookup
	WebElement arrivalCity;
	
	@FindBy(id="ctl00_mainContent_view_date1")
	@CacheLookup
	WebElement departDate;
	
	@FindBy(id="ctl00_mainContent_view_date2")
	@CacheLookup
	WebElement returnDate;
	
	@FindBy(id="divpaxinfo")
	@CacheLookup
	WebElement passengers;
	
	@FindBy(id="ctl00_mainContent_DropDownListCurrency")
	@CacheLookup
	WebElement currency;
	
	@FindBy(id="ctl00_mainContent_btn_FindFlights")
	@CacheLookup
	WebElement searchButton;
	
	@FindBy(id="divpaxinfo")
	@CacheLookup
	WebElement selectChildren;
	
	@FindBy(how=How.XPATH , using="//*[@id=\"dropdownGroup1\"]/div/ul[3]/li[9]/a")
	@CacheLookup
	WebElement city1;
	
	
	@FindBy(how=How.XPATH , using="//*[@id=\"dropdownGroup1\"]/div/ul[1]/li[8]/a")
	@CacheLookup
	WebElement city2;
	
	@FindBy(id="hrefIncChd")
	@CacheLookup
	WebElement children;
	
	
	

	public PageObjectRepository(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	public static WebDriver getWebDriver()
	{
		String path = "C:\\\\Users\\\\hripatil\\\\Downloads\\\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		driver = new ChromeDriver();
		
		return driver;
	}
	
	public WebElement getDepartureCity() {
		return departureCity;
	}


	public void setDepartureCity(WebElement departureCity) {
		this.departureCity = departureCity;
	}


	public WebElement getArrivalCity() {
		return arrivalCity;
	}


	public void setArrivalCity(WebElement arrivalCity) {
		this.arrivalCity = arrivalCity;
	}


	public WebElement getDepartDate() {
		return departDate;
	}


	public void setDepartDate(WebElement departDate) {
		this.departDate = departDate;
	}


	public WebElement getReturnDate() {
		return returnDate;
	}


	public void setReturnDate(WebElement returnDate) {
		this.returnDate = returnDate;
	}


	public WebElement getPassengers() {
		return passengers;
	}


	public void setPassengers(WebElement passengers) {
		this.passengers = passengers;
	}


	public WebElement getCurrency() {
		return currency;
	}


	public void setCurrency(WebElement currency) {
		this.currency = currency;
	}


	public WebElement getSearchButton() {
		return searchButton;
	}


	public void setSearchButton(WebElement searchButton) {
		this.searchButton = searchButton;
	}


	public WebElement getSelectChildren() {
		return selectChildren;
	}


	public void setSelectChildren(WebElement selectChildren) {
		this.selectChildren = selectChildren;
	}


	public WebElement getCity1() {
		return city1;
	}


	public void setCity1(WebElement city1) {
		this.city1 = city1;
	}


	public WebElement getCity2() {
		return city2;
	}


	public void setCity2(WebElement city2) {
		this.city2 = city2;
	}


	public WebElement getChildren() {
		return children;
	}


	public void setChildren(WebElement children) {
		this.children = children;
	}



}




//*[@id="ctl00_mainContent_ddl_originStation1"]
//*[@id="ctl00_mainContent_ddl_destinationStation1"]
//*[@id="ctl00_mainContent_view_date1"]
//*[@id="ctl00_mainContent_view_date2"]
//*[@id="divpaxinfo"]
//*[@id="ctl00_mainContent_DropDownListCurrency"]
//*[@id="ctl00_mainContent_btn_FindFlights"]
//*[@id="hrefIncChd"]                                 select children
//*[@id="dropdownGroup1"]/div/ul[3]/li[9]/a				mumbai
//*[@id="dropdownGroup1"]/div/ul[1]/li[8]/a 			chennai
//*[@id="hrefIncChd"]									child