package com.capg.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


	@RunWith(Cucumber.class)
	@CucumberOptions(features="C:\\Users\\hripatil\\Module 4 Workspace\\JobsWorld\\feature\\RegistrationForm.feature", glue="com.capg.stepdefinition")
	public class TestRunner {
		
		public static void main(String args[])
		{
			
		}

	}
