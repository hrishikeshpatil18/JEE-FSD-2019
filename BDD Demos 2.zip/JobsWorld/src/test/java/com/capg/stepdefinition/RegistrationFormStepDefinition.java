package com.capg.stepdefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.capg.pom.RegistrationFormPageFactory;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationFormStepDefinition {

	WebDriver driver;
	RegistrationFormPageFactory pageFactory;

	@Given("^user is on 'RegistrationForm' page$")
	public void user_is_on_RegistrationForm_page() throws Throwable {

		driver = pageFactory.getWebDriver();

		String url = "C:\\Users\\hripatil\\Module 4 Workspace\\JobsWorld\\target\\RegistrationForm.html";

		driver.get(url);
		pageFactory = new RegistrationFormPageFactory(driver);

	}

	@When("^user enters invalid user id \"(.*?)\"$")
	public void user_enters_invalid_user_id(String usrId) throws Throwable {

		WebElement userIdfield = pageFactory.getUserIdField();
		userIdfield.sendKeys(usrId);

	}

	@Then("^displays 'User Id should not be empty / length be between (\\d+) to (\\d+)'$")
	public void displays_User_Id_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {

		WebElement button = pageFactory.getSubmitButton();
		button.click();
		driver.switchTo().alert().accept();

		Thread.sleep(3000);
		driver.close();
	}

	@When("^user enters valid id \"(.*?)\"invalid password \"(.*?)\"$")
	public void user_enters_valid_id_invalid_password(String usrId, String password) throws Throwable {

		WebElement userIdfield = pageFactory.getUserIdField();
		userIdfield.sendKeys(usrId);

		WebElement passwordfield = pageFactory.getPasswordField();
		passwordfield.sendKeys(password);

	}

	@Then("^displays 'Password should not be empty / length be between (\\d+) to (\\d+)'$")
	public void displays_Password_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {

		WebElement button = pageFactory.getSubmitButton();
		button.click();
		driver.switchTo().alert().accept();

		Thread.sleep(3000);
		driver.close();
	}

	@When("^user enters   valid id \"(.*?)\" and valid password \"(.*?)\" invalid name \"(.*?)\"$")
	public void user_enters_valid_id_and_valid_password_invalid_name(String usrId, String password, String name)
			throws Throwable {

		WebElement userIdfield = pageFactory.getUserIdField();
		userIdfield.sendKeys(usrId);

		WebElement passwordfield = pageFactory.getPasswordField();
		passwordfield.sendKeys(password);

		WebElement namefield = pageFactory.getUserNameField();
		namefield.sendKeys(name);
	}

	@Then("^display 'Name should not be empty and must have alphabet characters only'$")
	public void display_Name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {

		WebElement button = pageFactory.getSubmitButton();
		button.click();
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}

	@When("^user enters  valid id \"(.*?)\" and valid password \"(.*?)\" valid name \"(.*?)\" invalid address \"(.*?)\"$")
	public void user_enters_valid_id_and_valid_password_valid_name_invalid_address(String usrId, String password,
			String name, String address) throws Throwable {

		WebElement userIdfield = pageFactory.getUserIdField();
		userIdfield.sendKeys(usrId);

		WebElement passwordfield = pageFactory.getPasswordField();
		passwordfield.sendKeys(password);

		WebElement namefield = pageFactory.getUserNameField();
		namefield.sendKeys(name);

		WebElement addressfield = pageFactory.getAddressField();
		addressfield.sendKeys(address);

	}

	@Then("^display 'User address must have alphanumeric characters only'$")
	public void display_User_address_must_have_alphanumeric_characters_only() throws Throwable {

		WebElement button = pageFactory.getSubmitButton();
		button.click();
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}

	@When("^user enters valid id \"(.*?)\" and valid password \"(.*?)\" valid name \"(.*?)\" valid address \"(.*?)\" invalid country$")
	public void user_enters_valid_id_and_valid_password_valid_name_valid_address_invalid_country(String usrId,
			String password, String name, String address) throws Throwable {

		WebElement userIdfield = pageFactory.getUserIdField();
		userIdfield.sendKeys(usrId);

		WebElement passwordfield = pageFactory.getPasswordField();
		passwordfield.sendKeys(password);

		WebElement namefield = pageFactory.getUserNameField();
		namefield.sendKeys(name);

		WebElement addressfield = pageFactory.getAddressField();
		addressfield.sendKeys(address);

		WebElement country = pageFactory.getUserIdField();
		Select select = new Select(country);
		select.selectByValue(" ");

	}

	@Then("^display 'Select your country from the list'$")
	public void display_Select_your_country_from_the_list() throws Throwable {

		WebElement button = pageFactory.getSubmitButton();
		button.click();
		driver.switchTo().alert().accept();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.close();

	}

	@When("^user enters  enters valid id \"(.*?)\" and valid password \"(.*?)\" valid name \"(.*?)\" valid address \"(.*?)\" invalid ZIP code \"(.*?)\"$")
	public void user_enters_enters_valid_id_and_valid_password_valid_name_valid_address_invalid_ZIP_code(String usrId,
			String password, String name, String address, String code) throws Throwable {

		WebElement userIdfield = pageFactory.getUserIdField();
		userIdfield.sendKeys(usrId);

		WebElement passwordfield = pageFactory.getPasswordField();
		passwordfield.sendKeys(password);

		WebElement namefield = pageFactory.getUserNameField();
		namefield.sendKeys(name);

		WebElement addressfield = pageFactory.getAddressField();
		addressfield.sendKeys(address);

		WebElement country = pageFactory.getCountry();
		Select select = new Select(country);
		select.selectByValue("DZ");

		WebElement codefield = pageFactory.getZipCodeField();
		codefield.sendKeys(code);

	}

	@Then("^display 'ZIP code must have numeric characters only'$")
	public void display_ZIP_code_must_have_numeric_characters_only() throws Throwable {

		WebElement button = pageFactory.getSubmitButton();
		button.click();
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}

	@When("^user enters valid id \"(.*?)\" and valid password \"(.*?)\" valid name \"(.*?)\" valid address \"(.*?)\" valid ZIP code \"(.*?)\" invalid email address \"(.*?)\"$")
	public void user_enters_valid_id_and_valid_password_valid_name_valid_address_valid_ZIP_code_invalid_email_address(
			String usrId, String password, String name, String address, String code, String mail) throws Throwable {

		WebElement userIdfield = pageFactory.getUserIdField();
		userIdfield.sendKeys(usrId);

		WebElement passwordfield = pageFactory.getPasswordField();
		passwordfield.sendKeys(password);

		WebElement namefield = pageFactory.getUserNameField();
		namefield.sendKeys(name);

		WebElement addressfield = pageFactory.getAddressField();
		addressfield.sendKeys(address);

		WebElement country = pageFactory.getCountry();
		Select select = new Select(country);
		select.selectByValue("DZ");

		WebElement codefield = pageFactory.getZipCodeField();
		codefield.sendKeys(code);

		WebElement mailfield = pageFactory.getEmailField();
		mailfield.sendKeys(mail);
	}

	@Then("^display 'You have entered an invalid email address!'$")
	public void display_You_have_entered_an_invalid_email_address() throws Throwable {

		WebElement button = pageFactory.getSubmitButton();
		button.click();
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}

	@When("^user enters user enters valid id \"(.*?)\" and valid password \"(.*?)\" valid name \"(.*?)\" valid address \"(.*?)\" valid ZIP code \"(.*?)\" valid email address \"(.*?)\" invalid sex$")
	public void user_enters_user_enters_valid_id_and_valid_password_valid_name_valid_address_valid_ZIP_code_valid_email_address_invalid_sex(
			String usrId, String password, String name, String address, String code, String mail) throws Throwable {

		WebElement userIdfield = pageFactory.getUserIdField();
		userIdfield.sendKeys(usrId);

		WebElement passwordfield = pageFactory.getPasswordField();
		passwordfield.sendKeys(password);

		WebElement namefield = pageFactory.getUserNameField();
		namefield.sendKeys(name);

		WebElement addressfield = pageFactory.getAddressField();
		addressfield.sendKeys(address);

		WebElement country = pageFactory.getCountry();
		Select select = new Select(country);
		select.selectByValue("DZ");

		WebElement codefield = pageFactory.getZipCodeField();
		codefield.sendKeys(code);

		WebElement mailfield = pageFactory.getEmailField();
		mailfield.sendKeys(mail);

		WebElement genderfield = pageFactory.getGender();
		// genderfield.click();

	}

	@Then("^display 'Please Select gender'$")
	public void display_Please_Select_gender() throws Throwable {

		WebElement button = pageFactory.getSubmitButton();
		button.click();
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}

	/*
	 * @When("^user enters valid id \"(.*?)\" and valid password \"(.*?)\" valid name \"(.*?)\" valid address \"(.*?)\" valid ZIP code \"(.*?)\" valid email address \"(.*?)\"$"
	 * ) public void
	 * user_enters_valid_id_and_valid_password_valid_name_valid_address_valid_ZIP_code_valid_email_address
	 * (String arg1, String arg2, String arg3, String arg4, String arg5, String
	 * arg6) throws Throwable {
	 * 
	 * }
	 */

	@When("^user enters valid id \"(.*?)\" and valid password \"(.*?)\" valid name \"(.*?)\" valid address \"(.*?)\" valid ZIP code \"(.*?)\" valid email address \"(.*?)\" valid gender$")
	public void user_enters_valid_id_and_valid_password_valid_name_valid_address_valid_ZIP_code_valid_email_address_valid_gender(
			String usrId, String password, String name, String address, String code, String mail) throws Throwable {

		WebElement userIdfield = pageFactory.getUserIdField();
		userIdfield.sendKeys(usrId);

		WebElement passwordfield = pageFactory.getPasswordField();
		passwordfield.sendKeys(password);

		WebElement namefield = pageFactory.getUserNameField();
		namefield.sendKeys(name);

		WebElement addressfield = pageFactory.getAddressField();
		addressfield.sendKeys(address);

		WebElement country = pageFactory.getCountry();
		Select select = new Select(country);
		select.selectByValue("DZ");

		WebElement codefield = pageFactory.getZipCodeField();
		codefield.sendKeys(code);

		WebElement mailfield = pageFactory.getEmailField();
		mailfield.sendKeys(mail);

		WebElement genderfield = pageFactory.getGender();
		genderfield.click();

	}

	@Then("^display 'Your Registration with JobsWorld\\.com has successfully done plz check your registred email addres to activate your profile'$")
	public void display_Your_Registration_with_JobsWorld_com_has_successfully_done_plz_check_your_registred_email_addres_to_activate_your_profile()
			throws Throwable {

		WebElement button = pageFactory.getSubmitButton();
		button.click();
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}

}
