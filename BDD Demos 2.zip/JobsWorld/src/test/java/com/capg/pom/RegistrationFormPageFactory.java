package com.capg.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationFormPageFactory {
	
	
static WebDriver driver;
	
	@FindBy(id="usrID")
	@CacheLookup
	WebElement userIdField;
	
	@FindBy(id="pwd")
	@CacheLookup
	WebElement passwordField;
	
	@FindBy(id="usrname")
	@CacheLookup
	WebElement userNameField;
	
	@FindBy(id="addr")
	@CacheLookup
	WebElement addressField;
	
	@FindBy(name="country")
	@CacheLookup
	WebElement country;
	
	@FindBy(name="zip")
	@CacheLookup
	WebElement zipCodeField;
	
	@FindBy(name="email")
	@CacheLookup
	WebElement emailField;
	
	@FindBy(name="sex")
	@CacheLookup
	WebElement gender;
	

	@FindBy(name="en")
	@CacheLookup
	WebElement language;
	
	@FindBy(id="desc")
	@CacheLookup
	WebElement aboutField;
	
	@FindBy(name="submit")
	@CacheLookup
	WebElement submitButton;
	
	
	
	public RegistrationFormPageFactory(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	
	public static WebDriver getWebDriver()
	{
		String path = "C:\\\\\\\\Users\\\\\\\\hripatil\\\\\\\\Downloads\\\\\\\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		driver = new ChromeDriver();
		
		return driver;
	}

	

	public WebElement getUserIdField() {
		return userIdField;
	}


	public void setUserIdField(WebElement userIdField) {
		this.userIdField = userIdField;
	}


	public WebElement getPasswordField() {
		return passwordField;
	}


	public void setPasswordField(WebElement passwordField) {
		this.passwordField = passwordField;
	}


	public WebElement getUserNameField() {
		return userNameField;
	}


	public void setUserNameField(WebElement userNameField) {
		this.userNameField = userNameField;
	}


	public WebElement getAddressField() {
		return addressField;
	}


	public void setAddressField(WebElement addressField) {
		this.addressField = addressField;
	}


	public WebElement getCountry() {
		return country;
	}


	public void setCountry(WebElement country) {
		this.country = country;
	}


	public WebElement getZipCodeField() {
		return zipCodeField;
	}


	public void setZipCodeField(WebElement zipCodeField) {
		this.zipCodeField = zipCodeField;
	}


	public WebElement getEmailField() {
		return emailField;
	}


	public void setEmailField(WebElement emailField) {
		this.emailField = emailField;
	}


	public WebElement getGender() {
		return gender;
	}


	public void setGender(WebElement gender) {
		this.gender = gender;
	}


	public WebElement getLanguage() {
		return language;
	}


	public void setLanguage(WebElement language) {
		this.language = language;
	}


	public WebElement getAboutField() {
		return aboutField;
	}


	public void setAboutField(WebElement aboutField) {
		this.aboutField = aboutField;
	}
	
	

	public WebElement getSubmitButton() {
		return submitButton;
	}


	public void setSubmitButton(WebElement submitButton) {
		this.submitButton = submitButton;
	}
	
	
}
