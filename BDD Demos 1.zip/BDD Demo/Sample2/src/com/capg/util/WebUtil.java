package com.capg.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebUtil {
	
	public static WebDriver getWebDriver( ) {
		String path = "D:\\\\Software\\\\chromedriver_win32\\\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver = new ChromeDriver();
		return driver;
	}

}
