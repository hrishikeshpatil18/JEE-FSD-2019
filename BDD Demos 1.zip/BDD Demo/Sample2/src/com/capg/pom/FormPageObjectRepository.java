package com.capg.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.util.WebUtil;

public class FormPageObjectRepository {
	
	static WebDriver driver;
	
	public static WebDriver getWebDriver() {
		driver = WebUtil.getWebDriver();
		return driver;
	}
	
	public static WebElement getPrice() {
		return driver.findElement(By.id("price"));
	}
	
	public static WebElement getQuantity() {
		return driver.findElement(By.id("quantity"));
	}
	
	public static WebElement getTotal() {
		return driver.findElement(By.id("total"));
	}
	
	public static WebElement getButton() {
		return driver.findElement(By.id("button"));
	}
}
