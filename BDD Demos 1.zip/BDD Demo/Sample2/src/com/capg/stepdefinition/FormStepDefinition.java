package com.capg.stepdefinition;

import org.openqa.selenium.WebDriver;

import com.capg.pom.FormPageObjectRepository;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FormStepDefinition {
	
	WebDriver driver;
	
	@Given("^User navigate to form page$")
	public void user_navigate_to_form_page() throws Throwable {
		driver = FormPageObjectRepository.getWebDriver();
	    String url = "D:\\STUDY\\BDD Workspace\\Sample2\\html\\form.html";
		driver.get(url);
	}

	@When("^User give valid price \"([^\"]*)\" and valid quantity \"([^\"]*)\"$")
	public void user_give_valid_price_and_valid_quantity(String price, String quantity) throws Throwable {
	    FormPageObjectRepository.getPrice().sendKeys(price);
	    FormPageObjectRepository.getQuantity().sendKeys(quantity);
	}

	@Then("^Result is displayed$")
	public void result_is_displayed() throws Throwable {
	    FormPageObjectRepository.getButton().click();
	    String result = FormPageObjectRepository.getTotal().getAttribute("value");
	    System.out.println(result);
	    Thread.sleep(1000);
	    driver.close();
	}
	
	@When("^User give invalid price \"([^\"]*)\" and valid quantity \"([^\"]*)\"$")
	public void user_give_invalid_price_and_valid_quantity(String price, String quantity) throws Throwable {
		FormPageObjectRepository.getPrice().sendKeys(price);
	    FormPageObjectRepository.getQuantity().sendKeys(quantity);
	}

	@Then("^Invalid alert message displayed$")
	public void invalid_alert_message_displayed() throws Throwable {
		FormPageObjectRepository.getButton().click();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		driver.close();
	}

}
