package com.capg;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test {

	public static void main(String[] args) {
		
		String path = "D:\\Software\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		String url = "https://hqporner.com/";
		driver.get(url);
		
		WebElement searchField = driver.findElement(By.name("q"));
		searchField.sendKeys("Big Tits");
		searchField.sendKeys("\n");
		
		WebElement element = driver.findElement(By.linkText("Fuck Him Well"));
		element.click();
		
		WebElement play = driver.findElement(By.id("iplb"));
		play.click();
		
	}

}
