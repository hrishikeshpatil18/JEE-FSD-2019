package com.capg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebUtil {

	
	public static WebDriver getWebDriver()
	{
		String path = "C:\\\\Users\\\\hripatil\\\\Downloads\\\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		WebDriver driver = new ChromeDriver();
		
		return driver;
	}
}
