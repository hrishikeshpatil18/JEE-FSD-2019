package com.capg.steps;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.capg.WebUtil;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {

	WebDriver driver;
	
	/*@FindBy(how=How.XPATH, using="//*[@id=\"loginButton\"]")
	@CacheLookup
	WebElement loginButton;*/

	@Given("^Navigate to Icompass url to display login page$")
	public void navigate_to_Icompass_url_to_display_login_page() throws Throwable {

		driver = WebUtil.getWebDriver();
		String url = "https://icompassweb.fs.capgemini.com";
		driver.get(url);

	}

	
	//Example concepet
	/*@When("^user enters login credentials username \"([^\"]*)\" and password \"([^\"]*)\"$")
	public void user_enters_login_credentials_username_and_password(String username, String password) throws Throwable {

		WebElement userTextField = driver.findElement(By.id("userName"));
		WebElement passwordTextField = driver.findElement(By.id("password"));

		userTextField.sendKeys(username);
		passwordTextField.sendKeys(password);

	}*/
	
	
	
	// Data table concept
	@When("^user enters login credentials$")
	public void user_enters_login_credentials(DataTable data) throws Throwable {
		
		List<List<String>> table =	data.raw();
		WebElement userTextField = driver.findElement(By.id("userName"));
		WebElement passwordTextField = driver.findElement(By.id("password"));

		String username =  table.get(0).get(0);
		String password = table.get(0).get(1);
		
		userTextField.sendKeys(username);
		passwordTextField.sendKeys(password);
		
	   
	}


	@Then("^Validaton should be performed$")
	public void validaton_should_be_performed() throws Throwable {

		WebElement loginButton = driver.findElement(By.id("loginButton"));
		loginButton.click();

	}

}
