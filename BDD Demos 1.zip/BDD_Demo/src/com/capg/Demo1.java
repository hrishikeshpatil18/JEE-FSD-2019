package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo1 {
	
	public static void main(String args[])
	{
		String path = "C:\\Users\\hripatil\\Downloads\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);  			//name of driver and path of driver
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("http:\\www.google.com");					//will open the chrome
		
		WebElement element  =	driver.findElement(By.name("q"));	//find the element first .. q is name of search bar
		
		element.sendKeys("chennai climate ");
		element.sendKeys("\n");
		//WebElement element2 = driver.findElement(By.className("sbl1"));
		//element2.click();
		
	}
	

}
