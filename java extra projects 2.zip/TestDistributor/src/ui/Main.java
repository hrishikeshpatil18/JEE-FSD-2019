package ui;
import dist.Distributor;
import prod.Product;
public class Main {
	
	public static void main(String args[])
	{
		Distributor dObj1=new Distributor("Mandeep","Chennai");
		Distributor dObj2=new Distributor("Satish","Mumbai");
		
		Product pObj1=new Product();
		Product pObj2=new Product();
	
	//	pObj1.getDetails();
		pObj1.calculateTotalPrice();
		pObj1.showDetails();
		System.out.println(pObj1);
		System.out.println(dObj1);
		
		//pObj2.getDetails();
		pObj2.calculateTotalPrice();
		pObj2.showDetails();
		System.out.println(pObj2);
		System.out.println(dObj2);
	}

}
