package prod;
import java.util.*;
import dist.Distributor;
public class Product{
	int productId;
	String productName;
	double productPrice;
	int quantity;
	double totalPrice;
	Distributor d;
	Scanner sc=new Scanner(System.in);
	
	
	public Product()
	{
		try
		{
			System.out.println("****Enter the product details***");
			System.out.println("Enter the product id");
			productId=sc.nextInt();
			System.out.println("Enter the product name");
			productName=sc.next();
			System.out.println("Enter the product price");
			productPrice=sc.nextDouble();
			System.out.println("Enter the quantity");
			quantity=sc.nextInt();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public Product(int productId, String productName, double productPrice, int quantity, Distributor d) 
	{
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.quantity = quantity;
		//this.totalPrice = totalPrice;
		this.d = d;
		
	}
	
	public Product(int productId, String productName, double productPrice, int quantity) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.quantity = quantity;
	}

	public Product(Product p, Distributor d)
	{
		this.productId = p.productId;
		this.productName = p.productName;
		this.productPrice = p.productPrice;
		this.quantity = p.quantity;
		this.totalPrice = p.totalPrice;
		//this.distributorName = d.distributorName;
		//this.address = d.address;
	}
	/*public void getDetails()
	{
		System.out.println("Enter the product details");
		productId=sc.nextInt();
		productName=sc.next();
		productPrice=sc.nextDouble();
		quantity=sc.nextInt();
	}*/
	public void calculateTotalPrice()
	{
		totalPrice=quantity*productPrice;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", quantity=" + quantity + ", totalPrice=" + totalPrice +"]";
	}
	
	
	public void showDetails()
	{
		System.out.println("Product id: "+productId);
		System.out.println("Product Name: "+productName);
		System.out.println("Product price: "+productPrice);
		System.out.println("Product quantity: "+quantity);
		System.out.println("Totoal price: "+totalPrice);
		//show();
	}

	
}
