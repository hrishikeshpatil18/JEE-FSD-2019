package generics;

public class Trial1<T> {
	T[] t;
	Trial1(T[] temp)
	{
		super();
		this.t=temp;
	}
	T[] get()
	{
		return t;
	}
	/*public <t> void display()
	{
		
	}*/

	public static void main(String args[])
	{
		Integer[] arr1={1,2,5,7,8,5};
		
		
		Trial1<Integer> obj=new Trial1<Integer>(arr1);
		Integer[] result=obj.get();
		for(int i=0;i<result.length;i++)
		System.out.print(result[i]+" ");
	
	}
}
