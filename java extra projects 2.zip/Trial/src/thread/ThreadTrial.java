package thread;

public class ThreadTrial extends Thread{
	
	public void run()
	{
		for(int i=0;i<5;i++)
			System.out.println(i);
	}
	public static void main(String args[])
	{
		ThreadTrial t1=new ThreadTrial();
		ThreadTrial t2=new ThreadTrial();
		t1.start();
		t2.start();
		t1.getName();
		
	}

}
