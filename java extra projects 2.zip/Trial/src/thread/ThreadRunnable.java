package thread;

public class ThreadRunnable implements Runnable {
	public void run()
	{
		for(int i=0;i<10;i++)
			System.out.println(i);
	}
	public static void main(String args[])
	{
		ThreadRunnable tr=new ThreadRunnable();
		Thread tobj=new Thread(tr);
		tobj.start();
		
		Thread tobj1=new Thread(tr);
		tobj1.start();
	}
}
