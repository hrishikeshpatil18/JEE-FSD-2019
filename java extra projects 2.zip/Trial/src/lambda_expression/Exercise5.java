package lambda_expression;

import java.util.function.*;

public class Exercise5 {
	public static void main(String agrs[])
	{
		Supplier<String> s=()->"Hello World";
		
		System.out.println(s.get());
		
		/*String result=(String) s.get();
		System.out.println(result);*/
	}

}
