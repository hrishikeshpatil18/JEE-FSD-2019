package lambda_expression;
interface Check
{
	int fun(int agr0,int arg1);
}
public class Exercise3 
{
	public static void main(String args[])
	{
		Check c=(num1,num2) -> {
								int min = num1>num2?num2:num1;
								return min;
							};
		int result=c.fun(20,40);
		System.out.println("Min= "+result);
	}
}
