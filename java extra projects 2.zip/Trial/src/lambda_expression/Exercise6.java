package lambda_expression;
import java.util.function.*;
public class Exercise6 
{
	public static void main(String args[])
	{
		BooleanSupplier bs=()->{return true;};
		System.out.println(bs.getAsBoolean());
		Boolean b=bs.getAsBoolean();
		System.out.println(b);
	}
}
