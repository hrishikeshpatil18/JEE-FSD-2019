package lambda_expression;
interface Sample
{
	String fun();
}
public class Exercise4 {
	public static void main(String args[])
	{
		Sample s=()->"Hello World";
		String ans=s.fun();
		System.out.println(ans);
	}

}
