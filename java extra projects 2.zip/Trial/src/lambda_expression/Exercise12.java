package lambda_expression;
import java.util.function.*;
public class Exercise12 
{
	public static void main(String args[])
	{
		BiFunction <Integer,Integer,Integer> bf=(num1,num2)->num1>num2?num2:num1;
		Integer ans=bf.apply(5,10);
		System.out.println("min is "+ans);
		
		BiFunction <Integer,Integer,Integer> bf1=Integer::sum;				//using method reference

		System.out.println("sum= "+bf1.apply(15,10));
		
	}
}
