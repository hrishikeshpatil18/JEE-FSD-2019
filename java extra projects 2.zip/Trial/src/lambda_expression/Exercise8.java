package lambda_expression;
import java.util.function.*;
public class Exercise8 
{
	public static void main(String args[])
	{
		IntConsumer con=(num)->System.out.println(num);
		con.accept(18);
	}
}
