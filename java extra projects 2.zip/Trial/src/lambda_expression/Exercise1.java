package lambda_expression;

interface Sum{
	int fun(int arg);
}
public class Exercise1{
	
	public static void main(String args[])
	{
		Sum s=(num)->num+10;
		int n=s.fun(10);
		System.out.println(n);
		
	}

}
