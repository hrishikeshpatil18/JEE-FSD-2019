package lambda_expression;
import java.util.function.*;
public class Exercise9 
{
	public static void main(String args[])
	{
		Predicate <Integer> pr=(num)->num>0;
		boolean b=pr.test(12);
		System.out.println(b);
	}
}
