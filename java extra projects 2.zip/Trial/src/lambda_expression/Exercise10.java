package lambda_expression;
import java.util.function.*;
public class Exercise10 
{
	public static void main(String args[])
	{
		Function <String,Integer> f =(str)->str.length();
		int a=f.apply("Hrishikesh Patil");
		System.out.println("lenght of string is "+a);
	}
}
