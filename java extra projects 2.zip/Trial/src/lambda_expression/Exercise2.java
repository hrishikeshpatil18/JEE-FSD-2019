package lambda_expression;
interface sum1
{
	int fun(int arg0,int arg1);
	}
public class Exercise2 
{
	public static void main(String args[])
	{
		sum1 s=(num1,num2)->num1+num2;
		int result=s.fun(10,20);
		System.out.println(result);
	}
}
