package lambda_expression;
import java.util.function.*;
public class Exercise7 
{
	public static void main(String args[])
	{
	Consumer <String> con=(msg)->System.out.println(msg);
	con.accept("Hrishikesh Patil");
	
	}
}
