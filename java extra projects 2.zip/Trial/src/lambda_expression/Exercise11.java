package lambda_expression;
import java.util.function.*;
public class Exercise11 {
	public static void main(String args[])
	{
		UnaryOperator <Integer> uo=(num)->num+10;
		System.out.println(uo.apply(40));
		
	}

}
