package lambda_expression;

 class Employee
{
	int id;
	String name;
	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	};
	
	
	
	/*Employee getEmployee(int id,String nm)
	{
		this.id=id;
		this.name=nm;
		return 
	}*/
}
public class ConstructorLambdaExp 
{
	public static void main(String args[])
	{
		Employee e1;
	}
}
