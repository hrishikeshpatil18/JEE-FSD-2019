
public class Sub extends Parent {

}
