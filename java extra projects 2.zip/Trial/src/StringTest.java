import java.util.Scanner;

public class StringTest 
{
	public static void main(String args[])
	{
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a string");
		String str=scanner.next();
		String ans="";
		for(int i=0;i<str.length();i++)
		{
			char ch=str.charAt(i);
			ch=(char) (ch+1);
			ans=ans+ch;
		}
		scanner.close();
		System.out.println(ans);
	}

}
