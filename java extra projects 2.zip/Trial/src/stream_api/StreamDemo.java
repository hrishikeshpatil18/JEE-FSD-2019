package stream_api;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamDemo {
	public static void main(String args[])
	{
		List<Integer> l=new ArrayList<Integer>();
		l.add(10);
		l.add(10);
		l.add(21);
		l.add(30);
		l.add(15);
		l.add(18);
		
		Stream<Integer> st=l.stream();
	
		Stream <Integer> s=st.filter(num1->num1%2==0);
		System.out.println("Even numbers ");
		//s.forEach((msg)->System.out.println(msg));
		
		List <Integer>lobj=s.collect(Collectors.toList());
		lobj.forEach(System.out::println);
		
		/*Stream <Integer>strmap=lobj.stream();
		Stream <Integer>mapnew=strmap.map(i->i+5);
		List <Integer> maplist=mapnew.collect(Collectors.toList());
		maplist.forEach(System.out::println);*/
		
		//Stream<Integer> newstream=l.stream();
		//Stream<Integer> diststream=newstream.distinct();
		//List<Integer> distlist=diststream.collect(Collectors.toList());
		
		 Optional<Integer> opt=lobj.stream().reduce((a,b)->a+b);
		 System.out.println("reduce method "+opt);
		
		List<Integer> distlist=lobj.stream().distinct().collect(Collectors.toList());
		System.out.println("Distinct method");
		 distlist.forEach(System.out::println);
		 
		
		
		List <Integer>updateMarklist=lobj.stream().map(i->i+5).collect(Collectors.toList());
		System.out.println("Count of even numbers "+lobj.stream().count());
		System.out.println("map method that adds 5 to even numbers");
		updateMarklist.forEach(System.out::println);
		
		Stream<Integer> st1=l.stream();
		Stream <Integer> s1=st1.filter(num1->num1%2!=0);
		System.out.println("Odd numbers ");
		s1.forEach((msg)->System.out.println(msg));
		
		//s.forEach(System.out::println);
			
	}

}
