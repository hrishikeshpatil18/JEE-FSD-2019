
class Main
{
	
	static void input(Parent p)
	{
		
	}
	public static void main(String args[])
	{
		Parent pobj=new Parent();
		Sub s=new Sub();
		input(pobj);
		input(s);
	}
}