package collection;

public class Set {
	

}
