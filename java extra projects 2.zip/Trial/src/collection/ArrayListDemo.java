package collection;

import java.util.*;

//import java.util.*;
public class ArrayListDemo {
	public static void main(String args[])
	{
		List<String> ls=new ArrayList<String>();
		ls.add("Hrishikesh");
		ls.add("abc");
		ls.add("xyz");
		ls.add("hrishikeshPAtil");
		//ls.add(12);
		//ls.add(10);
		//ls.add(15.47);
		//Collections.sort(ls);
		System.out.println(ls);
		System.out.println(ls.size());
		System.out.println(ls.add("1548"));
		System.out.println(ls);
		System.out.println(ls.contains("poi"));	
		ls.remove(2);
		System.out.println(ls);
		System.out.println(ls.get(1));
		
		String max;
		max=ls.get(0);
		for(int i=0;i<3;i++)
		{
			String temp=ls.get(i+1);
			
			if(max.length()<temp.length())
			{
				max=temp;
			}
		}
		System.out.println(max);
		
	}
}
