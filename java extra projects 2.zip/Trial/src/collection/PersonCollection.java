package collection;

public class PersonCollection {
	

}
