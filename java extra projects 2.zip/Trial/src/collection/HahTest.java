package collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.Map;
import java.util.Scanner;

public class HahTest {
	//private static final Map<String, String>  = null;
	public static void main(String args[])
	{
		Map <String, String> map=new HashMap <String, String> ();
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter size");
		int size=scanner.nextInt();
		for(int i=0;i<size;i++)
		{
			String s1=scanner.next();
			String s2=scanner.next();
			map.put(s1, s2);
		}
		
		System.out.println("enter org name");
		String org=scanner.next();
		
		List<String> res1= new ArrayList<String>();
		
		if(map.containsValue(org))
		{
			res1=getEmployeesName( (HashMap<String, String>) map,org);
			for(String res2:res1) {
				System.out.println(res2);
			}
		}
		else
		{
			System.out.println("no data");
		}
	}
	public static List<String> getEmployeesName(HashMap<String,String> employeeList,String organization)
	{
		List<String> list=new ArrayList<String>();
		//(List<String>) EmpList.keySet();
		
		String res="";
		Set <String> set=employeeList.keySet();
		for(String str: set)
		{
			String value=employeeList.get(str);
			if(value.equals(organization))
			{
				res=str;
				list.add(res);
			}
		}
		return list;
		
	}

}
