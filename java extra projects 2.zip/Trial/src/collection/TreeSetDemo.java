package collection;
import java.util.*;
public class TreeSetDemo {
	public static void main(String args[])
	{
		TreeSet <Integer> ts=new TreeSet <Integer>();
		ts.add(11);
		ts.add(50);
		ts.add(14);
		ts.add(547);
		ts.add(41);
		ts.add(0);
		System.out.println(ts);
		Iterator i=ts.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
}
