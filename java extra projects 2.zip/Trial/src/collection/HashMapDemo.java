package collection;
import java.util.*;
public class HashMapDemo {
	public static void main(String args[])
	{
		HashMap <Integer,String> hm=new HashMap <Integer,String>();
	
	hm.put(1,"Hrishikesh");
	hm.put(3,"Hrishi");
	hm.put(2,"HP");
	System.out.println(hm);
	
	//Set set=hm.entrySet();
	
	}
}
