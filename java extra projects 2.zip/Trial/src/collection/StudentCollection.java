package collection;

import java.util.*;

class Student {
	String name;
	int id;
	public Student(int id,String name) {
		super();
		this.name = name;
		this.id = id;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", id=" + id + "]";
	}

}
public class StudentCollection
{
	public static void main(String args[])
	{
		Student s1=new Student(1,"Hrishi");
		Student s2=new Student(2,"Abc");
		Student s3=new Student(3,"xyz");
		List <Student> l=new ArrayList <Student> ();
		l.add(s1);
		l.add(s2);
		l.add(s3);
		System.out.println(l);
		l.remove(1);
		System.out.println(l);
		
		Iterator i=l.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
}
