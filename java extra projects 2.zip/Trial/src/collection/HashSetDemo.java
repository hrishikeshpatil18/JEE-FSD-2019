package collection;

import java.util.*;

public class HashSetDemo {

	public static void main(String args[])
	{
		HashSet<String> s=new HashSet<String>();
		
		
		//Set<String> s=new HashSet<String>();
		s.add("Hrishikesh");
		s.add("abc");
		s.add("xyz");
		s.add("xyz");
		//ls.add(12);
		//ls.add(10);
		//ls.add(15.47);
		System.out.println(s);
		System.out.println(s.size());
		System.out.println(s.add("1548"));
		System.out.println(s);
		System.out.println(s.contains("poi"));	
		s.remove(2);
		System.out.println(s);
		
		Iterator i=s.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
}
