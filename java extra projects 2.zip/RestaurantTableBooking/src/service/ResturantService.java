package service;

import bean.Customer;
import bean.Table;
import dao.ResturantDAO;

public class ResturantService 
{

	Table tobj1;
	ResturantDAO rdao=new ResturantDAO();
	public void bookTable(int cid,Table tobj)
	{
		rdao.storeTableDetails(cid,tobj);
	}
	
	public Table getDetails(int cus)
	{
		Table to=rdao.getCustomerDetails(cus);
		return to;
	}
	
	public void addTable(int add1)
	{
		rdao.addmethod(add1);
	}
}
