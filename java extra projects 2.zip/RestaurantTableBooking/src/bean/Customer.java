package bean;

public class Customer 
{
	static int i=1;
	int cusId;
	String cusName;
	long phNo;
	
	public Customer(String cusName,long phno) {
		super();
		this.cusId=cusId+i;
		this.cusName = cusName;
		this.phNo =phno;
		i++;
	}
	
	public Customer(int id,String cusName,long phno) {
		super();
		this.cusId=cusId;
		this.cusName = cusName;
		this.phNo =phno;
	}
	
	public int getCusId() {
		return cusId;
	}
	public void setCusId(int cusId) {
		this.cusId = cusId;
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public long getPhNo() {
		return phNo;
	}
	public void setPhNo(long phNo) {
		this.phNo = phNo;
	}
	@Override
	public String toString() {
		return "Customer [cusId=" + cusId + ", cusName=" + cusName + ", phNo=" + phNo + "]";
	}
	

	
	
	
}
