package bean;


enum TableCapacity
{
	TWO,FOUR,SIX,EIGHT;
}
public class Table 
{
	static int i=1; 
	int tid;
	String tc;
	Customer cus;
	
	
	public Table(Customer cus, String tc)
	{
		this.cus=cus;
		this.tid=tid+i;
		Table(tid,tc);
		i++;
	}
	public void Table(int tid2, String tc2) {
		this.tid = tid2;
		this.tc = tc2;
		
	}
	public Table(int tid, String tc) {
		super();
		this.tid = tid;
		this.tc = tc;
	}

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public String getTc() {
		return tc;
	}

	public void setTc(String tc) {
		this.tc = tc;
	}

	@Override
	public String toString() {
		return "Table [tid=" + tid + ", tc=" + tc + ", cus=" + cus + "]";
	}
	
	
	
}
