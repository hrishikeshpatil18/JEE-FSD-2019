package dao;

import java.util.HashMap;
import java.util.Set;

import bean.*;

public class ResturantDAO 
{
	int totalTable=2;
	int add=0;
	static HashMap <Integer,Table> hash=new HashMap <Integer,Table>();
	public void storeTableDetails(int cid1,Table t1)
	{
		int s=hash.size();
		if(s!=(totalTable+this.add))
		{
		hash.put(cid1,t1);
		System.out.println("Table Booked Successfully...!!");
		System.out.println(hash);
		}
		else
			System.out.println("Tables are not available");
		
			
	}
	
	public Table getCustomerDetails(int cus)
	{
		Set<Integer>s=hash.keySet();
		for(int i:s)
		{
			if(i==cus)
			{
				return hash.get(i);
			}
		}
		return null;
		
	}
	public void addmethod(int add)
	{
		this.add=add;
	}
}
