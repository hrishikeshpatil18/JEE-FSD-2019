package ui;

import java.util.Scanner;

import service.ResturantService;
import bean.Customer;
import bean.Table;


public class Main 
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int ch=0;
		String s="";
		ResturantService robj=new ResturantService();
		
		do 
		{
			System.out.println("1. Book a Table");
			System.out.println("2. add new table to resturant");
			System.out.println("Display customer details based on customer id");
			System.out.println("Exit");
			System.out.println("Enter your choice");
			ch=sc.nextInt();
			
			switch(ch)
			{
				case 1:
					System.out.println("Enter the name of customer");
					String name=sc.next();
					System.out.println("Enter the phone number of customer");
					long phno=sc.nextLong();
					Customer cobj=new Customer(name,phno);
					System.out.println(cobj);
					System.out.println("Enter the capacity of table");
					String cap=sc.next();
					Table tobj=new Table(cobj,cap);
					System.out.println(tobj);
					ResturantService rservice=new ResturantService();
					rservice.bookTable(cobj. getCusId() ,tobj);
					break;
				case 2:
					System.out.println("Enter the number of tables u want to add");
					int add=sc.nextInt();
					robj.addTable(add);
					break;
				case 3:
					System.out.println("Enter customer id:");
					int cusid=sc.nextInt();
					Table get=robj.getDetails(cusid);
					System.out.println(get);
					break;
				case 4:
					System.exit(0);
					break;
				
			}
			System.out.println("Do you want to continue ..??");
			s=sc.next();
		}while(s.equals("Y")||s.equals("y"));
	}
}
