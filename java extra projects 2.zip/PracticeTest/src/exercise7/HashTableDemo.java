package exercise7;					//hashtable is thread safe collection

import java.util.Hashtable;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class HashTableDemo 
{
	public static void main(String args[])
	{
		int key;
		String value,s;
		
		Scanner scanner=new Scanner(System.in);
		
	Map<Integer,String> map=new Hashtable<Integer,String>();
		do
		{
			System.out.println("Enter the key");
			key=scanner.nextInt();
			System.out.println("Enter the value for entered key");
			value=scanner.next();
		
			map.put(key, value);
			
			
			System.out.println("do u want to conitnue....Y/y");
			s=scanner.next();
		}while(s.equals("Y")||s.equals("y"));
		System.out.println("***** Hashtable Data ****");
		System.out.println(map);
		System.out.println("Enter the key");
		int getkey=scanner.nextInt();
		
		Set <Integer> set=map.keySet();
		int flag=0;
		for(int i:set)
		{
			if(getkey==i)
			{
				System.out.println(map.get(i));
				flag=1;
			}
		}
		if(flag==0)
			System.out.println("No matching key found");
				
		scanner.close();	
	}

}
