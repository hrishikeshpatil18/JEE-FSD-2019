package exercise12;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class RunnableIntf implements Runnable
{
	public void run()
	{
		int i=0;
		while(i<10)
		{
		 try 
		 {
			 
			 System.out.println(Thread.currentThread().getName());
				
			 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd   HH:mm:ss");  
			 LocalDateTime now = LocalDateTime.now();  
			 System.out.println(dtf.format(now));  
			 Thread.sleep(2000);
			i++;
		} catch (InterruptedException e) {e.printStackTrace();} 
	}
	}
	public static void main(String args[])
	{
		RunnableIntf robj1=new RunnableIntf();
		RunnableIntf robj2=new RunnableIntf();
		RunnableIntf robj3=new RunnableIntf();
		
		Thread tobj1=new Thread(robj1);
		Thread tobj2=new Thread(robj2);
		Thread tobj3=new Thread(robj3);
		tobj1.start();
		tobj2.start();
		tobj3.start();
	}

}
