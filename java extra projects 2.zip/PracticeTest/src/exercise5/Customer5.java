package exercise5;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;


public class Customer5 
{
	int customerId;
	String customerName;
	long customerphn;
	String customerCity;
	static String s;
	public Customer5()
	{ 
		
	}
	
	
	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public Customer5(int customerId, String customerName, long customerphn, String customerCity) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerphn = customerphn;
		this.customerCity = customerCity;
	}

	@Override
	public String toString() {
		return "Customer4 [customerId=" + customerId + ", customerName=" + customerName + ", customerphn=" + customerphn
				+ ", customerCity=" + customerCity + "]";
	}
	
	public static void main(String args[])
	{
		int id;
		String name,city;
		long phn;
		Scanner scanner=new Scanner(System.in);
		
		Set<Customer5> set=new HashSet<Customer5>();
		do
		{
			System.out.println("Enter the customer id");
			id=scanner.nextInt();
			System.out.println("Enter the customer name");
			name=scanner.next();
			System.out.println("Enter the customer phone number");
			phn=scanner.nextLong();
			System.out.println("Enter the customer city");
			city=scanner.next();
			Customer5 customer=new Customer5(id,name,phn,city);
			System.out.println(customer);
			
			set.add(customer);
			System.out.println("do u want to conitnue....Y/y");
			s=scanner.next();
		}while(s.equals("Y")||s.equals("y"));
		System.out.println("Enter the customer id to remove");
		int getid=scanner.nextInt();
		//System.out.println(set);
				
		Iterator<Customer5> iterator=set.iterator();
		while(iterator.hasNext())
		{
			
			Customer5 cus=(Customer5) iterator.next();
			int cid=cus.getCustomerId();
			if(cid==getid)
			{
				System.out.println(cid+"   ***"+getid);
				break;
				//set.remove(iterator.next());
				//System.out.println("successfully removed");
			}
			break;
			
		}
		set.remove(iterator.next());
		System.out.println("successfully removed");
		System.out.println(set);
		
	}
	
}
