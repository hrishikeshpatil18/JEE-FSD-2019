package exercise11;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MiltipleThreadDemo extends Thread
{
	public void run()
	{
		
		while(true)
		{
		 try {
			 System.out.println(Thread.currentThread().getName());
				
			 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd   HH:mm:ss");  
			 LocalDateTime now = LocalDateTime.now();  
			 System.out.println(dtf.format(now));  
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} }
		
	}
	
	public static void main(String args[])
	{
		MiltipleThreadDemo obj1=new MiltipleThreadDemo();
		MiltipleThreadDemo obj2=new MiltipleThreadDemo();
		MiltipleThreadDemo obj3=new MiltipleThreadDemo();
		MiltipleThreadDemo obj4=new MiltipleThreadDemo();
		
		obj1.start();
		obj2.start();
		obj3.start();
		obj4.start();
	}
}
