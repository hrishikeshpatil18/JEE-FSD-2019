package exercise16;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileHandling 
{

	public static void main(String args[])
	{
		long phn;
		String name,city;
		Scanner scanner=new Scanner(System.in);
		try
		{
			FileWriter fw=new FileWriter("C:\\\\Users\\\\hripatil\\\\Desktop\\\\output.txt");
			BufferedWriter bfw=new BufferedWriter(fw);
			PrintWriter pw=new PrintWriter(bfw);
			
			System.out.println("Enter the mobile number");
			phn=scanner.nextInt();
			System.out.println("Enter the customer name");
			name=scanner.next();
			System.out.println("Enter the customer city");
			city=scanner.next();
			String data=phn+" "+name+" "+city;
			System.out.println(data);
			pw.println(data);
			
			pw.close();
			bfw.close();
			fw.close();
			
			System.out.println("Enter the mobile number");
			String mbno=scanner.next();
			FileReader fr=new FileReader("C:\\\\Users\\\\hripatil\\\\Desktop\\\\output.txt");
			BufferedReader bfr=new BufferedReader(fr);
			while(bfr.ready())
			{
				String line=bfr.readLine();
				String userData[]=line.split(" ");
				if(userData[0].equals(mbno))
					System.out.println(line);
				else
					System.out.println("mobile no is not matching");
			}
			bfr.close();
			fr.close();
			scanner.close();
			
		}catch(FileNotFoundException e) {System.out.println(e);}
		catch(IOException e) {System.out.println(e);}
	}
}
