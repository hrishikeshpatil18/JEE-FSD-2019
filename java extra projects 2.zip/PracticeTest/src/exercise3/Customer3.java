package exercise3;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;


public class Customer3 
{

	int customerId;
	String customerName;
	long customerphn;
	String customerCity;
	static String s;
	public Customer3()
	{ 
		
	}
	public Customer3(int customerId, String customerName, long customerphn, String  customerCity) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerphn = customerphn;
		this. customerCity =  customerCity;
	}
	@Override
	public String toString() {
		return "Customer3 [customerId=" + customerId + ", customerName=" + customerName + ", customerphn=" + customerphn
				+ ", city=" +  customerCity + "]";
	}
	
	public static void main(String args[])
	{
		int id;
		String name,city;
		long phn;
		Scanner scanner=new Scanner(System.in);
		HashMap<Integer,Customer3> hash=new HashMap<Integer,Customer3>();
		
		do
		{
			System.out.println("Enter the customer id");
			id=scanner.nextInt();
			System.out.println("Enter the customer name");
			name=scanner.next();
			System.out.println("Enter the customer phone number");
			phn=scanner.nextLong();
			System.out.println("Enter the customer city");
			city=scanner.next();
			Customer3 customer=new Customer3(id,name,phn,city);
			System.out.println(customer);
			
			hash.put(id,customer);
			System.out.println("do u want to conitnue....Y/y");
			s=scanner.next();
		}while(s.equals("Y")||s.equals("y"));
		System.out.println("Enter the customer id");
		int id1=scanner.nextInt();
		
		Set <Integer> set=hash.keySet();
		int flag=0;
		for(int i:set)
		{
			if(id1==i)
			{
				System.out.println(hash.get(i));
				flag=1;
			}
			
		}
		if(flag==0)
			System.out.println("No matching values");	
		
	}
}
