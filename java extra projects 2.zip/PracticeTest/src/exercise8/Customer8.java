package exercise8;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import exercise3.Customer3;

public class Customer8 
{
	int customerId;
	String customerName;
	long customerphn;
	String customerCity;
	static String s;
	public Customer8()
	{ 
		
	}
	public Customer8(int customerId, String customerName, long customerphn, String  customerCity) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerphn = customerphn;
		this. customerCity =  customerCity;
	}
	@Override
	public String toString() {
		return "Customer8 [customerId=" + customerId + ", customerName=" + customerName + ", customerphn=" + customerphn
				+ ", city=" +  customerCity + "]";
	}
	
	
	public static void main(String args[])
	{
		int id;
		String name,city;
		long phn;
		Scanner scanner=new Scanner(System.in);
		Hashtable<Integer,Customer8> hash=new Hashtable<Integer,Customer8>();
		
		do
		{
			System.out.println("Enter the customer id");
			id=scanner.nextInt();
			System.out.println("Enter the customer name");
			name=scanner.next();
			System.out.println("Enter the customer phone number");
			phn=scanner.nextLong();
			System.out.println("Enter the customer city");
			city=scanner.next();
			Customer8 customer=new Customer8(id,name,phn,city);
			System.out.println(customer);
			
			hash.put(id,customer);
			System.out.println("do u want to conitnue....Y/y");
			s=scanner.next();
		}while(s.equals("Y")||s.equals("y"));
		System.out.println("Enter the customer id to remove hastable object");
		int id1=scanner.nextInt();
		
		Set<Integer> set=hash.keySet();
		for(int i:set)
		{
			if(i==id1)
			{
				hash.remove(i);
				System.out.println("Removed Successfully");
				break;
			}
		}
		System.out.println("Updated Hash Table");
		System.out.println(hash);
		scanner.close();
		
	}
}
