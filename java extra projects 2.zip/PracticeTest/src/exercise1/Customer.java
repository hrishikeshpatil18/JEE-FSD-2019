package exercise1;

import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class Customer implements Comparable<Customer>
{
	int customerId;
	String customerName;
	static String s;
	public Customer(int customerId, String customerName) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
	}
	
	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + "]";
	}


	public static void main(String args[])
	{
		Scanner scanner=new Scanner(System.in);
		int id;
		String name;
		TreeSet <Customer> treeset=new TreeSet<Customer>();
		do
		{
			System.out.println("Enter the customer id");
			id=scanner.nextInt();
			System.out.println("Enter the customer name");
			name=scanner.next();
			Customer customer=new Customer(id,name);
			//System.out.println(customer);
			
			treeset.add(customer);
			System.out.println("do u want to conitnue....Y/y");
			s=scanner.next();
		}while(s.equals("Y")||s.equals("y"));
		Iterator<Customer> iterator=treeset.iterator();
	
		System.out.println("*** Tree set objects are:");
		while(iterator.hasNext())
		{
			System.out.println(iterator.next());
		}
		scanner.close();
			
		
	}


	@Override
	public int compareTo(Customer c) {
		// TODO Auto-generated method stub
		if(this.customerId>c.getCustomerId())
			return 1;
		else if(this.customerId==c.getCustomerId())
			return 0;
		else
		return -1;
	}

}
