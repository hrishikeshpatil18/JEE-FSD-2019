package exercise15;

import java.io.Serializable;

public class Customer implements Serializable
{
	int id;
	String name,city;
	public Customer(int id, String name, String city) {
		super();
		this.id = id;
		this.name = name;
		this.city = city;
	}
	
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", city=" + city + "]";
	}
	
	
	
	
}
