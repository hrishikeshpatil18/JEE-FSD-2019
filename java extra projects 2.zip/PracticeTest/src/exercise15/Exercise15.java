package exercise15;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class Exercise15 
{
	public static void main(String args[])
	{
		int id;
		String name,city;
		Scanner scanner=new Scanner(System.in);
		try
		{
			
			
			System.out.println("Enter the customer id");
			id=scanner.nextInt();
			System.out.println("Enter the customer name");
			name=scanner.next();
			System.out.println("Enter the customer city");
			city=scanner.next();
			Customer customer=new Customer(id,name,city);
			System.out.println(customer);
			
			FileOutputStream fos=new FileOutputStream("C:\\Users\\hripatil\\Desktop\\output.txt");
			ObjectOutputStream oos=new ObjectOutputStream(fos);
			
			oos.writeObject(customer);
			System.out.println("object successfully written to file");
			oos.close();
			scanner.close();
		}
		catch(FileNotFoundException e) {System.out.println(e);}
		catch(IOException e) {System.out.println(e);}
	}

}
