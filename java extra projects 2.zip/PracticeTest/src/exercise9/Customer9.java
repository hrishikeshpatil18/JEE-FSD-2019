package exercise9;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;


public class Customer9 
{
	int customerId;
	String customerName;
	
	static String s;
	public Customer9()
	{ 
		
	}
	public Customer9(int customerId, String customerName) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
	
	}
	@Override
	public String toString() {
		return "Customer8 [customerId=" + customerId + ", customerName=" + customerName +  "]";
	}
	
	public static void main(String args[])
	{
		int id;
		String name;
		
		Scanner scanner=new Scanner(System.in);
		List<Customer9> list=new LinkedList<Customer9>();
		
		do
		{
			System.out.println("Enter the customer id");
			id=scanner.nextInt();
			System.out.println("Enter the customer name");
			name=scanner.next();
	
			Customer9 customer=new Customer9(id,name);
			System.out.println(customer);
			list.add(customer);
		
			System.out.println("do u want to conitnue....Y/y");
			s=scanner.next();
		}while(s.equals("Y")||s.equals("y"));
	
		System.out.println("Enter the customer id to store at 5th position");
		id=scanner.nextInt();
		System.out.println("Enter the customer name to store at 5th position");
		name=scanner.next();
		Customer9 customer=new Customer9(id,name);
		list.add(5,customer);
		System.out.println(list);
		System.out.println("the customer object  stored at 3rd position: 	"+list.get(2));
		System.out.println();
		
		scanner.close();
	}
}
