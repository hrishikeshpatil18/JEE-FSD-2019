package exercise2;

import java.util.Collection.*;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.TreeSet;

import exercise1.Customer;

public class Customer2 implements Comparable<Customer2>
{

	int customerId;
	String customerName;
	static String s;
	public Customer2()
	{ 
		
	}
	public Customer2(int customerId, String customerName) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
	}
	
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	@Override
	public String toString() {
		return "Customer2 [customerId=" + customerId + ", customerName=" + customerName + "]";
	}
	public static void main(String args[])
	{
		int id;
		String name;
		Scanner scanner=new Scanner(System.in);
		TreeSet<Customer2> treeset=new TreeSet<Customer2>();
		do
		{
			System.out.println("Enter the customer id");
			id=scanner.nextInt();
			System.out.println("Enter the customer name");
			name=scanner.next();
			Customer2 customer2=new Customer2(id,name);
			System.out.println(customer2);
			
			treeset.add(customer2);
			System.out.println("do u want to conitnue....Y/y");
			s=scanner.next();
		}while(s.equals("Y")||s.equals("y"));
		
		System.out.println("*** Tree set objects are:");
		
		Iterator<Customer2> iterator=treeset.iterator();
		while(iterator.hasNext())
		{
			System.out.println(iterator.next());
		}
		scanner.close();
	}
	
	
	@Override
	public int compareTo(Customer2 c) {
		// TODO Auto-generated method stub
		if(this.customerId>c.getCustomerId())
			return 1;
		else if(this.customerId==c.getCustomerId())
			return 0;
		else
		return -1;
	}
}
