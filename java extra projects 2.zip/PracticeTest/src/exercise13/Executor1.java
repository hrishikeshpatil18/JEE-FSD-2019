package exercise13;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Executor1 implements Runnable
{
	String s;
	public  Executor1 (String s)
	{
		this.s=s;
	}
	public void run()
	{
		int i=0;
		while(i<10)
		{
		 try 
		 {
			 
			 System.out.println(Thread.currentThread().getName());
				
			 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd   HH:mm:ss");  
			 LocalDateTime now = LocalDateTime.now();  
			 System.out.println(dtf.format(now));  
			 Thread.sleep(2000);
			i++;
		} catch (InterruptedException e) {e.printStackTrace();} 
	}
	}
	public static void main(String args[])
	{
		ExecutorService executor=Executors.newFixedThreadPool(3);
		executor.execute(new Executor1("Thread-1"));
		executor.execute(new Executor1("Thread-2"));
		executor.execute(new Executor1("Thread-3"));
		
	}
}
