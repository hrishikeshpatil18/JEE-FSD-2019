package com.capg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import bean.Employee;

public class EmpDAO {
	DBUtil dbobj=new DBUtil();
	
	public int addEmployee(Employee empobj) 
	{
		int n=0;
		try
		{
			Connection con=dbobj.getConnection();
			String insertQuery="insert into employee values(?,?,?)";
			PreparedStatement pstmt=con.prepareStatement(insertQuery);
			
			pstmt.setInt(1, empobj.getEid());
			pstmt.setString(2, empobj.getEname());
			pstmt.setDouble(3, empobj.getSalary());
			
			n=pstmt.executeUpdate();
			con.close();
			
		}
		catch(SQLException e){ System.out.println(e); }
		return n;
	}

}
