package bean;

public class Employee {
	
	private int eid;
	private String ename;
	private double salary;
	
	
	
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", salary=" + salary + "]";
	}
	public int getEid() {
		// TODO Auto-generated method stub
		return eid;
	}
	
	
	

}
