import org.junit.Test;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;
public class SampleMockitoJavaTest
{

	@Test
	public void test()
	{
		SampleMockito sm=mock(SampleMockito.class);
		when(sm.sum(3,2)).thenReturn(5);
		assertTrue(sm.sum(3,2)==5);
	}
}
