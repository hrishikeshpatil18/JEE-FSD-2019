
public class SampleMockito {
	public int sum(int i,int j)
	{
		return i+j;
	}

}
