import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileDemo {

	public static void main(String[] args) {

		List<String> list = new ArrayList<String>();

		File file = new File("C:\\Users\\spavanku\\Desktop\\test.txt");

		try {
			FileReader reader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(reader);
			while (bufferedReader.ready()) {
				list.add(bufferedReader.readLine());
			}
		} catch (FileNotFoundException e) {
			System.out.println(e.getLocalizedMessage());
		} catch (IOException e) {
			e.printStackTrace();
		}

		List<Employee> employeesList = new ArrayList<>();

		for (String string : list) {

			String array[] = string.split("-");

			double salary = Double.parseDouble(array[2]);

			if (salary > 50000) {
				Employee employee = new Employee(Integer.parseInt(array[0]), array[1], salary);
				employeesList.add(employee);
			}

		}

		for (Employee employee : employeesList) {
			System.out.println(employee.getId() + ":" + employee.getName() + ":" + employee.getSalary());
		}
	}

}
