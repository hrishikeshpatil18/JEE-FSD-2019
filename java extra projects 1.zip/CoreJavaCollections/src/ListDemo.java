import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class ListDemo {

	public static void main(String[] args) {

		// common behavior of map is:
		// when u add the duplicate key the old value will be replaced by new value

		List<Integer> list = new ArrayList<Integer>();

		Map<Integer, String> map = new TreeMap<>(); // type safety //java 1.5 feature

		Scanner scanner = new Scanner(System.in);
		System.out.println("How many entries u want to add:");
		int choice = scanner.nextInt();

		for (int i = 0; i < choice; i++) {
			int id = scanner.nextInt();
			String name = scanner.next();
			map.put(id, name);
		}

		System.out.println("Enter second input to check:");
		String input2 = scanner.next();

		// iteration

		Set<Integer> set = map.keySet();
		Iterator<Integer> iterator = set.iterator();
		while (iterator.hasNext()) {
			int id = iterator.next();
			String name = map.get(id);

			if (name.equals(input2)) {
				list.add(id);
			}
		}
		System.out.println(list);
	}
}
