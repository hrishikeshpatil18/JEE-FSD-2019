package service;
import bean.Customer;
import bean.Mobile;
import dao.MobileDAO;
import ui.MobileUI;
public class MobileService {
	
	public void storeMobDetailsServ(Mobile e)
	{
		MobileDAO mbd=new MobileDAO();
		mbd.storeMobileDetails(e);
	}
	
	Mobile getMobDetailsServ()
	{
		getMobileDetails();
	}
	public void storeCustDetailsSer(Customer cs)
	{
		MobileDAO mbd1=new MobileDAO();
		mbd1.storeCustomerDetails(cs);
	}
	
	

}
