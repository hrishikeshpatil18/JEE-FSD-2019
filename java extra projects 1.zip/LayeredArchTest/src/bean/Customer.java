package bean;

public class Customer {
	int custId;
	String name;
	String state;
	long mbNo;
	
	//Mobile m1=new Mobile();
	
	public Customer()
	{
		
	}
	public Customer(int custId, String name, String state, long mbNo) {
		super();
		this.custId = custId;
		this.name = name;
		this.state = state;
		this.mbNo = mbNo;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public long getMbNo() {
		return mbNo;
	}
	public void setMbNo(long mbNo) {
		this.mbNo = mbNo;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", state=" + state + ", mbNo=" + mbNo + "]";
	}
	
	
	

}
