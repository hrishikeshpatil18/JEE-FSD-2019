package bean;

public class Mobile {
	long phnNo;
	 String simType1="";
	
	String state;
	
	
	public Mobile(long phnNo, String simType1, String state) {
		super();
		this.phnNo = phnNo;
		this.simType1 = simType1;
		this.state = state;
	}

	public long getPhnNo() {
		return phnNo;
	}

	public void setPhnNo(long phnNo) {
		this.phnNo = phnNo;
	}

	public String getSimType1() {
		return simType1;
	}

	public void setSimType1(String simType1) {
		this.simType1 = simType1;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "Mobile [phnNo=" + phnNo + ", simType1=" + simType1 + ", state=" + state + "]";
	}

	

	
	
	
	

	
}
