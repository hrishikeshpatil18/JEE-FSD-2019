package ui;
import java.util.Scanner;

import bean.Customer;
import bean.Mobile;
import dao.MobileDAO;
import service.MobileService;
public class MobileUI {

	
	
	public static void main(String args[])
	{
		long pNo;
		String sType1;
		String st;
		
		int custId;
		String custName;
		String state;
		long no;
		String str;
		//MobileDAO mdao=new MobileDAO();
		MobileService mbs=new MobileService();
		MobileService mbs1=new MobileService();
		Scanner sc=new Scanner(System.in);
		System.out.println("1. Display Mobile Details");
		System.out.println("2. Add Mobile Details");
		System.out.println("3. Add Customer Details");
		System.out.println("4. Display Customer Details");
		System.out.println("5. Exit");
		
		System.out.println("Enter your choice");
		int ch=sc.nextInt();
		do
		{
			switch(ch)
			{
				case 1:
					Mobile mb1=new Mobile(8482995628l,"National","TN");
					System.out.println(mb1);
					Mobile mb2=new Mobile(9579449181l,"International","MH");
					System.out.println(mb2);
					Mobile mb3=new Mobile(8668445095l,"National","GJ");
					System.out.println(mb3);
					Mobile mb4=new Mobile(9763444749l,"International","KA");
					System.out.println(mb4);
					Mobile mb5=new Mobile(8256874120l,"National","GA");
					System.out.println(mb5);
					break;
					
				case 2:
					System.out.println("Enter your mobile details");
					System.out.println("Enter your mobile number");
					pNo=sc.nextLong();
					
					System.out.println("Enter your SIM type");
					sType1=sc.next();
					System.out.println("Enter your state");
					st=sc.next();
					Mobile m=new Mobile(pNo,sType1,st);
					System.out.println(m);
					mbs.storeMobDetailsServ(m);
					System.out.println("Mobile details saved");
					break;
				case 3:
					System.out.println("Add Customer Details");
					System.out.println("Add Customer Id");
					custId=sc.nextInt();
					System.out.println("Add Customer Name");
					custName=sc.next();
					System.out.println("Enter your state");
					st=sc.next();
					System.out.println("Enter your mobile number");
					no=sc.nextLong();
					Customer c1=new Customer(custId,custName,st,no);
					mbs1.storeCustDetailsSer(c1);
					System.out.println("Customer details saved");
					break;
					
					
					
			}
			System.out.println("Do you want to continue...?? Y/y");
			str=sc.next();
		}while(str.equals("Y") || str.equals("y"));
	}
	
}
