package dao;
import bean.*;
public class MobileDAO 
{

		
		Mobile mobArray[]=new Mobile[10];
		Customer custArray[]=new Customer[10];
		static int count=0;
		static int count1=0;
		public void storeMobileDetails(Mobile e)
		{
			mobArray[count]=e;
			System.out.println(mobArray[count]);
			count++;
		}
		
		public Mobile[] getMobileDetails()
		{
			Mobile mbAray[]=new Mobile[10];
			for(int i=0;i<mobArray.length;i++)
			{
				 mbAray[]=mobArray[i];
			}
			return mobArray;
		}
		
		public void storeCustomerDetails(Customer custom)
		{
			custArray[count1]=custom;
			System.out.println(custArray[count1]);
			count++;
		}
	}


