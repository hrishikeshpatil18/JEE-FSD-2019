
public @interface AssumeEqual {

}
