import static org.junit.Assert.assertTrue;
import static org.junit.Assume.assumeTrue;
import  static org.junit.jupiter.api.Assertions.*;
import java.util.List.*;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.DynamicTest.*;

import java.util.Arrays;
import java.util.List;

@TestInstance(Lifecycle.PER_CLASS)
class TestAddNumbers {

	AddNumbers obj;
	@BeforeAll
	static void initClass()
	{
		System.out.println("Before All");
	}
	@BeforeEach
	void init()
	{
		 obj=new AddNumbers();
		System.out.println("Before Each");
	}
	
	@Test
	@DisplayName("assertequals mathod")
	void test() 
	{
		
		//AddNumbers obj=new AddNumbers();
		int expected=7;
		int actual=obj.addition(2,5);
		assertEquals(expected,actual);
	}
	
	
	@Test
	@DisplayName("assertNotEquals method")
	void test1() 
	{
		
		//AddNumbers obj=new AddNumbers();
		int expected=40;
		int actual=obj.addition(10,20);
		assertNotEquals(expected,actual);
	}
	
	@Test
	@DisplayName("AssertAll method")
	void test2() 
	{
		//AddNumbers obj=new AddNumbers();
		assertAll(
					()->assertEquals(20,obj.addition(10,10)),
					()->assertEquals(100,obj.addition(10,90)),
					()->assertNotEquals(100,obj.addition(110,90))
				);
	}
	@Test
	@DisplayName("AssumeTrue method")
	void testAssumption()
	{
		boolean serverstatus=true;
		System.out.println("*****Assume true*******");
		assumeTrue(serverstatus);
	}
	
	@AfterEach
	void aftereach()
	{
		System.out.println("After Each");
	}
	@AfterAll
	static void afterall()
	{
		System.out.println("After All");
	}
	
	@RepeatedTest(3)
	void testRepeat(RepetitionInfo repetitionInfo )
	{
	System.out.println("Repetition #"+repetitionInfo.getCurrentRepetition());	
	assertEquals(3,repetitionInfo.getTotalRepetitions());
	}

	@TestFactory
	List<DynamicTest> dynamicTestDemo()
	{
		return Arrays.asList(
				dynamicTest("Simple dynamic test",()->assertTrue(true)),
				dynamicTest("Exception excutables",()->assertTrue(true)),
				dynamicTest("Simple dynamic test 2",()->assertTrue(true))
				);
	}
	
	@ParameterizedTest
	@DisplayName("ParameterizedTest")
	@ValueSource(ints= {1,2,3})
	void test_ValueSource(int i)
	{
		assertTrue(i<5);
	}
	
	@ParameterizedTest
	@DisplayName("ParameterizedTest String")
	@ValueSource(strings= {"1","2","3"})
	void test_ValueSourceString(String s)
	{
		assertTrue(Integer.parseInt(s)<5);
	}
	
	enum ColorType
	{
		RED,GREEN,BLUE,PINK;
	}
	@ParameterizedTest
	@EnumSource(ColorType.class)
	void test_enumSource(ColorType ct)
	{
		System.out.println("Enum: "+ct);
	}
	
	static Stream<String> ms()
	{
		return Stream.of("A","B");
	}
	
	@ParameterizedTest
	@MethodSource("ms")
	void testMethod(String s)
	{
		assertNotNull(s);
	}
	
	@ParameterizedTest
	@CsvSource(delimiter=',', value= {"1,A","2,B"})
	void test_CsvSource(int i,String s)
	{
		assertTrue(3>i);
		assertTrue(Arrays.asList("A","B").contains(s));
	}
	
	
}
