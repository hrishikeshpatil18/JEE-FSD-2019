
public class AddNumbers {
	public int addition(int num1,int num2)
	{
		int result=num1+num2;
		return result;
	}
	public boolean same(int n1,int n2)
	{
		if(n1==n2)
			return true;
		return false;
	}
}
