package com.cg.client;

import java.util.Scanner;

public class client {
	static int id=0;
	public static void main(String[] args) {
		
		while(true) {
			System.out.println("****WELCOME TO XYZ BANK****\n");
			System.out.println("    1.Create Account\n");
			System.out.println("    2.Show Balance\n");
			System.out.println("    3.Deposit\n");
			System.out.println("    4.Withdraw\n");
			System.out.println("    5.Fund Transfer\n");
			System.out.println("    6.Print Transaction\n");
			System.out.println("    7.Exit\n");
			System.out.println("Enter your choice:\n");
			@SuppressWarnings("resource")
			Scanner sc=new Scanner(System.in);
			int choice=sc.nextInt();
			CustomerUi cuobj=new CustomerUi();
			switch(choice) {
				case 1:
					cuobj.createCustomer();
					break;
				case 2:
					cuobj.showBalance();
					break;
				case 3:
					cuobj.deposit();
					break;
				case 4:
					cuobj.withdraw();
					break;
				case 5:
					cuobj.fundTransfer();
					break;
				case 6:
					cuobj.printTransaction();
					break;
				case 7:
					System.exit(0);
			}	
		}
	}
}
