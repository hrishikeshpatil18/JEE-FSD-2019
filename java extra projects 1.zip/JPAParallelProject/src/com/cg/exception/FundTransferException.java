package com.cg.exception;

public class FundTransferException extends Exception {
	public FundTransferException(String s) {
		System.out.println(s);
	}

}
