package com.cg.exception;

public class DepositException extends Exception {
	public DepositException(String s)
	{
		System.out.println(s);
	}
}
