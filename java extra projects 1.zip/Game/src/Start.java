import java.util.Scanner;

public class Start {
	static void startgame()
	{
		System.out.println("method start has called");
		String s1[]={"C__N__I","_U__A_","_A___L__R_","K__K__A","H__ER__B__",};
		String s2[]={"CHENNAI","MUMBAI","BANGALORE","KOLKATA","HYDERABAD"};
		
		int a=(int)Math.random()*10;
		System.out.println(a);
		int b=a;
		String city=s1[a];
		System.out.println(city);
		
		System.out.println("Guess the city name:");
		Scanner sc=new Scanner(System.in);
		
		//while(i<3)
		//do
		//{
		//System.out.println("Make your attempt 1");
			for(int i=1;i<=3;i++)
			{
				System.out.println("Make your attempt "+i);
				String ans=sc.next();
				if(ans.equals(s2[b]))
					{
						System.out.println("Correct Answer");
						break;
					}
				else
				{
					System.out.println("Wrong Answer....");
					//break;
				}
			}
			System.out.println("Correct answer is "+s2[b]);
		}//while()
	//}
		
		public static void main(String args[])
		{
			startgame();
		}
}

