import java.util.Scanner;

public class Main {
		static void start()
		{
			System.out.println("method start has called");
			String s1[]={"C__N__I","_U__A_","_A___L__R_","K__K__A","H__ER__B__",};
			String s2[]={"CHENNAI","MUMBAI","BANGALORE","KOLKATA","HYDERABAD"};
			
			int a=(int)(Math.random()*10);
			System.out.println(a);
			int b=a;
			String city=s1[a];
			System.out.println(city);
			
			System.out.println("Guess the city name:");
			Scanner sc=new Scanner(System.in);
			
				for(int i=1;i<=3;i++)
				{
					System.out.println("Make your attempt "+i);
					String ans=sc.next();
					if(ans.equals(s2[b]))
						{
							System.out.println("Correct Answer");
							break;
						}
					else
					{
						System.out.println("Wrong Answer....");
						//break;
					}
				}
				System.out.println("Correct answer is "+s2[b]);
			}
		
		static void description()
		{
			System.out.println("method description has called ");
		}
		static void exit()
		{
			System.out.println("method exit has called ");
			System.exit(0);
		}
	public static void main(String args[])
	{
		String s="";
		do
		{
			
			Scanner sc=new Scanner(System.in);
			
			System.out.println("MENU:");
			System.out.println("1. START");
			System.out.println("2. DESCRIPTION");
			System.out.println("3. EXIT");	
			System.out.println("Enter your choice");
			int ch=sc.nextInt();
			switch(ch)
			{
				case 1:
					start();
					break;
				case 2:
					description();
					break;
				case 3:
					exit();
					break;
				default:
					System.out.println("Invalid choice");
			}
			System.out.println("Do you want to continue ..?? Y/N");
			s=sc.next();
			
		}
		while(s.equals("Y") || s.equals("y"));
	}
}
