package ui;
import bean.Employee;
import service.EmployeeService;

import java.util.*;
public class EmployeeUI {
	public static void main(String args[])
	{
		EmployeeService es1=new EmployeeService();
		Scanner sc=new Scanner(System.in);
		int id;
		String name;
		double sal;
		System.out.println("Enter the Employee details: ");
		System.out.println("Employee id: ");
		id=sc.nextInt();
		System.out.println("Employee name: ");
		name=sc.next();
		System.out.println("Employee salary: ");
		sal=sc.nextDouble();
		
		Employee e=new Employee(id,name,sal);

		es1.storeEmpService(e);
		System.out.println(e);
	}

}
