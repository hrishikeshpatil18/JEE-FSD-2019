package service;
import bean.Employee;
import dao.EmployeeDAO;
import ui.EmployeeUI;
public class EmployeeService implements Service{
	double newsal;
	Employee e=new Employee();
	EmployeeDAO ed=new EmployeeDAO();
	
	public void calculateInsentive(double sal)
	{
		newsal=e.getSalary()+5000;
		e.setSalary(newsal);
		
	}
	public void storeEmpService(Employee em)
	{
		ed.storeEmployeeDetails(em);
	}

}
