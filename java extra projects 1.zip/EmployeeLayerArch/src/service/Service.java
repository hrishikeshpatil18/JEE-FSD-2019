package service;

import bean.Employee;

public interface Service {

	void calculateInsentive(double sal);
	public void storeEmpService(Employee em);
	
}
