package dao;
import bean.Employee;
import service.EmployeeService;
public class EmployeeDAO implements EmpDAO {
	
	Employee earr[]=new Employee[2];
	static int count=0;
	public void storeEmployeeDetails(Employee e)
	{
		earr[count]=e;
		System.out.println(earr[count]);
		count++;
	}
	
	public Employee getEmployeeDetails(int id) 
	{
		for(Employee e:earr)
		{
			if(id==e.getEmpId())
			
		}
		return ;
	}

	}
}
