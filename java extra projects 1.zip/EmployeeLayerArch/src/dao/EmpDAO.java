package dao;

import bean.Employee;

public interface EmpDAO {
	void storeEmployeeDetails(Employee e);
	Employee getEmployeeDetails();

}
